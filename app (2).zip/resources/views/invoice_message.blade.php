<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
  <p>Dear Sir,<br>
      Your Booking ID-[{{$booking_id}}] is confirmed. Please Check Your Invoice File.<br>
      Thank You.
  </p>
</body>
</html>
