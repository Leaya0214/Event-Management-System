<!DOCTYPE html>
<html>
<head>
    <title>Bridal Harmony</title>
</head>
<body>
  <p>Dear {{$user->name}},<br>
       Please Check Your Payment Slip.<br>
      Thank You.

  </p>
</body>
</html>
