<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
  <p>Dear Sir,<br>
        We got your selection from your end. Sir, expected delivery date is-{{$delivery_date ? $delivery_date: ''}}.</p>
    <p style="margin-top: 14px">For any other query Contact with us : +88 0177171 1590 or +88 0174222 5584</p>
</body>
</html>
