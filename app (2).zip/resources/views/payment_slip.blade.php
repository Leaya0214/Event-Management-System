<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
  <p>Dear Sir,<br>
      For Your Booking ID-[{{$booking_id}}] . Please Check Your Payment Slip.<br>
      Thank You.
  </p>
</body>
</html>
