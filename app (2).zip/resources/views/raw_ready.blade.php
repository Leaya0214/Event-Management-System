<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
  <p>Dear Sir,<br>
           Your Booking Id-<span style="color: rgb(0, 0, 253)"> [{{ $booking_id}}] </span> Event Date <span style="color: rgb(0, 0, 253)">[{{ $event_date }}]</span>, Event Venue <span style="color: rgb(0, 0, 253)">[{{ $venue }}]</span> Raw Photos & Videos are ready
        for delivery. Please Collect it from our office. Please bring Pendrive/Hard Drive. After getting all
        Raw Photos please select photos for Editing.</p>

    <p style="margin-top: 10px">Photo Selection Giving Process: You can give us photo number of upload selected photos to a
      drive & give that drive link here selection.bridalharmony@gmail.com</p>

    <p style="margin-top: 10px">Video Song Selection Process : Give us you tube song link here. Atleast 1 song for trailer & 7-8
      song for Cine Edit.</p>
    <p style="margin-top: 14px; color:brown">Note : Give this selection as soon as possible. If you give us selection lately then final edit will be
        late.</p>
    <p style="margin-top: 14px">For any other query Contact with us : +88 0177171 1590 or +88 0174222 5584</p>
</body>
</html>
