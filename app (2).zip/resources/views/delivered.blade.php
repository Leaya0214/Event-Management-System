<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
  <p>Dear Sir,<br>
           Your Booking Id-<span style="color: rgb(0, 0, 253)"> [{{ $booking_id}}] </span> Event Date <span style="color: rgb(0, 0, 253)">[{{ $event_date }}]</span>, Event Venue <span style="color: rgb(0, 0, 253)">[{{ $venue }}]</span> Products are ready
        for delivery. Please Collect it from our office.</p>

    <p style="margin-top: 14px">For any other query Contact with us : +88 0177171 1590 or +88 0174222 5584</p>
</body>
</html>
