@extends('BackEnd.master')

@section('content')
    <style>
        .child-table {
            width: 100%;
            border-collapse: collapse;
        }

        .child-table tbody tr td {
            padding-top: 0px !important;
            padding-bottom: 5px;
            padding-left: 20px;
            border-bottom: 1px solid #d9d6d6;
        }
        .btn-table tbody tr td {
            padding-top: 3px !important;
            padding-bottom: 0 !important;
            padding-left: 10px;
            border: none !important;
            /* border-bottom: 1px solid #d9d6d6; */
        }

        .main-table tbody tr td,
        .main-table thead tr th {
            padding: 0.85rem 0.85rem;
            text-align: left;
        }

        @media (min-width:1400px) {
            table td {
                /* padding-left: 0px ; */

            }

            .table> :not(caption)>*>*,
            .datepicker table> :not(caption)>*>* {
                padding: 0px;
            }
        }

        .hide {
            display: none;
        }
        ::placeholder {
            color: red;
            opacity: 1; /* Firefox */
        }

        ::-ms-input-placeholder { /* Edge 12-18 */
        color: red;
        }

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css">

      <div class="container">
        <h4 class="mb-4">Filter Event Data</h4>
        <div class="row">
            <div class="col-md-3">
                <select name="" id="status" class="form-select">
                    <option value="all">Select Status</option>
                    <option value="0">Pending</option>
                    <option value="1">Active</option>
                    <option value="2">Deactive</option>
                    <option value="3">Raw Ready For Delivery</option>
                    <option value="7">Raw Delivered</option>
                    <option value="4">Selection Given</option>
                    <option value="5">Final Ready</option>
                    <option value="6">Delivered</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="" id="payment_status" class="form-select">
                    <option value="all">Select Payment Status</option>
                    <option value="unpaid">Unpaid</option>
                    <option value="partial">Partial Paid</option>
                    <option value="full">Full Paid</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="event" id="filter-event" class="form-select chosen-select">
                    <option value="all">Select Booking Number</option>
                    @foreach ($events as $f_event)
                        <option value="{{ $f_event->id }}">{{ $f_event->booking_id }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <select name="district" id="district" class="form-select chosen-select">
                    <option value="all">Select District</option>
                    @foreach ($districts as $district)
                        <option value="{{ $district->district_id }}">{{ $district->district }}</option>
                    @endforeach
                </select>
            </div>

        </div>
        <div class="row mt-3">
            <div class="col-md-3">
                <select name="" id="type" class="form-select chosen-select">
                    <option value="all">Select Event Type</option>
                    @foreach ($types as $type)
                        <option value="{{ $type->type_id }}">{{ $type->type_name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <select name="" id="shift" class="form-select chosen-select">
                    <option value="all">Select Event Shift</option>
                    @foreach ($shifts as $shift)
                        <option value="{{ $shift->shift_id }}">{{ $shift->shift_name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <select name="" id="category" class="form-select chosen-select">
                    <option value="all">Select Event Package</option>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->category_name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <select name="district" id="package" class="form-select chosen-select">
                    <option value="all">Select Event Package Type</option>
                    @foreach ($packages as $package)
                        <option value="{{ $package->id }}">{{ $package->name }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-3">
                <input type="text" class="form-control" id="from-date" placeholder="From Date"
                    onfocus="(this.type='date')">
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control" id="to-date" placeholder="To Date"
                    onfocus="(this.type='date')">
            </div>
            <div class="col-md-3">
                <button type="button" class="btn btn-success" id="filter">Filter Data </button>
            </div>
        </div>
    </div>
        
    <div class="col-md-12 grid-margin stretch-card mt-4">
        <div class="card">
            <div class="card-body">
                <div class="row pr-3">
                    <div class="col-md-6">
                        <h6 class="card-title">Events</h6>
                        <p class="text-muted mb-3">Manage All Events</p>
                    </div>
                </div>
                <div class="table-responsive pt-3" id="show">
                    <table class="table table-bordered main-table" data-table="true" id="eventTable">
                        <thead>
                             <tr>
                                <th>#</th>
                                <th>Booking No</th>
                                 <th>Event Date</th>
                                <th>Booking Info</th>
                                <th>Action</th>
                                <th>Add New</th>
                                <th>Status</th>
                                 <th>Payment Info</th>
                                <th>Assign</th>
                                <th>Add Expense</th>
                                <th>Event Type</th>
                                <th>Selection Date</th>
                                <th>Event Shift</th>
                                <th>Event Time</th>
                                <th>Package</th>
                                <th>Package Name</th>
                                 <th>Experience</th>
                                <th>Delivery Date</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                     <table class="table table-bordered main-table" data-table="true" id="selectionTable" style="display: none">
                        <thead>
                              <tr>
                                <th>#</th>
                                <th>Selection Date</th>
                                <th>Delivery Date</th>
                                <th>Booking No</th>
                                <th>Booking Info</th>
                                <th>Action</th>
                                <th>Add New</th>
                                <th>Add Expense</th>
                                <th>Status</th>
                                <th>Payment Info</th>
                                <th>Assign</th>
                                <th>Event Type</th>
                                <th>Event Date</th>
                                <th>Event Shift</th>
                                <th>Event Time</th>
                                <th>Package</th>
                                <th>Package Name</th>
                                 <th>Experience</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    @foreach ($events as $event)
        @php
            $details  = $event->details;
            $eventDetails = $event->details;
            $payment = $event->payment;
        @endphp
        {{-- Status Udate Modal  --}}
        @foreach($details as $s_detail)
          <div class="modal fade status_modal-{{ $s_detail->id }}" id="status_modal_{{ $s_detail->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <div id="successMessage_{{ $s_detail->id }}" class="alert alert-success" style="display: none;"></div>

                    <form id="status-form-{{ $s_detail->id }}" data-id="{{ $s_detail->id }}">
                        <div class="modal-body">
                            <div class="form-group row">
                                <label for="status" class="col-sm-3">Edit Status</label>
                                <label for="status" class="col-sm-1">:</label>
                                <div class="col-md-8">
                                    <select name="status" id="status" class="form-control">
                                        <option value="">Select Status</option>
                                        <option value="1">Active</option>
                                        <option value="2">Deactive</option>
                                        <option value="3">Raw Ready For delivery</option>
                                        <option value="7">Raw Delivered</option>
                                        <option value="4">Selection Given</option>
                                        <option value="5">Final Delivery</option>
                                        <option value="6">Delivered</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-sm btn-primary" >Update</button>
                            <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
         @php
            $artists = App\Models\BackEnd\EventDetailsLog::whereIn('event_details_id', $details->pluck('id'))->get();
            $customerReviews = App\Models\CustomerExperience::whereIn('detail_id', $details->pluck('id'))->get();
            $officeReviews = App\Models\OfficeExperience::whereIn('detail_id', $details->pluck('id'))->get();
            $artistReviews = App\Models\BackEnd\PhotographerExperience::whereIn('event_detail_id', $details->pluck('id'))->get();
        @endphp
            <div class="modal fade officeExperience-{{ $s_detail->id }}"  id="shareExperince-{{ $s_detail->id }}" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg ">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                        </div>
                        <form action="{{ route('experinceStore') }}" method="POST" enctype="multipart/form-data"  id="shareExperinceForm-{{ $s_detail->id }}"  data-id="{{ $s_detail->id }}">
                            @csrf
                            <input type="hidden" name="detail_id" value="{{$s_detail->id }}">
                                <div class="modal-body">
                                    <div class="form-group row pt-3">
                                        <div class="col-sm-12">
                                            <label for="artist" class="form-label text-bold"><strong>Select Artist</strong> </label>
                                            <select name="artist_id" id="artist" class="form-control">
                                                @foreach($artists as $v_artist)
                                                    <option value="{{$v_artist->assigned_user_id}}">{{$v_artist->user->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row pt-3">
                                        <div class="col-sm-12">
                                            <label for="experience" class="form-label text-bold"><strong>Share Experience</strong> </label>
                                            <textarea name="experience" class="form-control" id="" cols="30" rows="10" placeholder="Share Yore Experience About The Artist"></textarea>
                                        </div>
                                    </div>

                                    <div id="message-container-{{ $s_detail->id }}" class="mt-3 border-1 p-2">

                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </form>

                    </div>
                </div>
            </div>
           
            <div class="modal fade viewExperience-{{ $s_detail->id }}" id="" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg ">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="text-center">Event Experiences</h4>
                            <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                        </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        @if(count($customerReviews)>0)
                                            <h5 class="text-center py-3">Customer Review To Artists</h5>
                                            <table class="table table-hover table-bordered table-striped" width="100%">
                                                <thead >
                                                    <tr>
                                                        <th  class="p-3" width="10%">Artist Name</th>
                                                        <th  class="p-3" width="15%">Artist Designation</th>
                                                        <th  class="p-3" width="75%">Customer Review</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <style>
                                                        td.p-3.new-td {
                                                                overflow: hidden;
                                                                text-overflow: ellipsis;
                                                                white-space: normal; 
                                                                max-height: 500px;
                                                                width: 100%;
                                                                display: -webkit-box;
                                                                -webkit-line-clamp: 3;
                                                                }
                                                    </style>
                                                    @foreach($customerReviews as $v_review)
                                                    <tr>
                                                        <td  class="p-3" width="10%">{{ $v_review->artist->name}}</td>
                                                        <td  class="p-3" width="15%">{{ $v_review->artist->designation}}</td>
                                                        <td  class="p-3 new-td" width="75%"> {{ $v_review->experience}}</td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @endif
                                        @if(count($officeReviews)>0)
                                            <h5 class="text-center pt-4 pb-4">Office Review To Artists</h5>
                                            <table class="table table-hover table-bordered table-striped" width="100%">
                                                <thead >
                                                    <tr>
                                                        <th  class="p-3" width="10%">Artist Name</th>
                                                        <th  class="p-3" width="15%">Artist Designation</th>
                                                        <th  class="p-3" width="75%">Office Review</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <style>
                                                        td.p-3.new-td {
                                                                overflow: hidden;
                                                                text-overflow: ellipsis;
                                                                white-space: normal; 
                                                                max-height: 500px;
                                                                width: 100%;
                                                                display: -webkit-box;
                                                                -webkit-line-clamp: 3;
                                                                }
                                                    </style>
                                                    @foreach($officeReviews as $office_review)
                                                    <tr>
                                                        <td  class="p-3" width="10%">{{ $office_review->user->name}}</td>
                                                        <td  class="p-3" width="15%">{{ $office_review->user->designation}}</td>
                                                        <td  class="p-3 new-td" width="75%"> {{ $office_review->experience}}</td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @endif
                                        @if(count($artistReviews)>0)
                                            <h5 class="text-center pt-4 pb-4">Artist Review To Customer</h5>
                                            <table class="table table-hover table-bordered table-striped" width="100%">
                                                <thead >
                                                    <tr>
                                                        <th  class="p-3" width="10%">Artist Name</th>
                                                        <th  class="p-3" width="15%">Artist Designation</th>
                                                        <th  class="p-3" width="75%">Review</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <style>
                                                        td.p-3.new-td {
                                                                overflow: hidden;
                                                                text-overflow: ellipsis;
                                                                white-space: normal; 
                                                                max-height: 500px;
                                                                width: 100%;
                                                                display: -webkit-box;
                                                                -webkit-line-clamp: 3;
                                                                }
                                                    </style>
                                                    @foreach($artistReviews as $artist_review)
                                                    <tr>
                                                        <td  class="p-3" width="10%">{{ $artist_review->user->name}}</td>
                                                        <td  class="p-3" width="15%">{{ $artist_review->user->designation}}</td>
                                                        <td  class="p-3 new-td" width="75%"> {{ $artist_review->experience}}</td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @endif
                                    </div>
                                </div>
                               
                            </div>
                    </div>
                </div>
            </div>
                @endforeach
         <div class="modal fade view_modal-{{ $event->id }}" id="" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl ">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h3 class="text-white">Event Information</h3>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th class="p-3">Booking ID</th>
                                            <th class="p-3">Client Name</th>
                                            <th class="p-3">Client Email</th>
                                            <th class="p-3">Phone</th>
                                            <th class="p-3">Alternate Number</th>
                                            <th class="p-3">Bride Name</th>
                                            <th class="p-3">Groom Name</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="p-3">{{ $event->booking_id }}</td>
                                            <td class="p-3">{{ $event->client->name }}</td>
                                            <td class="p-3">{{ $event->client->email }}</td>
                                            <td class="p-3">{{ $event->client->primary_no }}</td>
                                            <td class="p-3">{{ $event->client->alternate_no }}</td>
                                            <td class="p-3">{{ $event->bride_name }}</td>
                                            <td class="p-3">{{ $event->groom_name }}</td>
                                            
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                            @if($payment)
                            <div class="col-md-12 mt-3">
                                <h3 class="text-center mb-3">Payment Information</h3>
                                <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th class="p-3">Booking ID</th>
                                            <th class="p-3">Payment Amount</th>
                                            <th class="p-3">Paid</th>
                                            <th class="p-3">Due</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="p-3">{{ $payment->event_master->booking_id }}</td>
                                            <td class="p-3">{{ $payment->payment_amount }}</td>
                                            <td class="p-3">{{ $payment->advance }}</td>
                                            <td class="p-3">{{ $payment->due_amount }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                            @endif
                             <div class="col-md-12  mt-4">
                                <p class=""> <span class="text-bold" style="font-size:20px; "> <b>Client Instructions : </b></span> {{ $event->instructions }}</p>
                                <p></p>
                            </div>
                            <div class="col-md-12 mt-3 mb-3">
                                <p class=""> <span class="text-bold" style="font-size:20px; "> <b>Office Instructions : </b></span> {{ $event->office_instructions }}</p>
                            </div>
                        </div>
                        @php
                            $eventDetails = App\Models\BackEnd\EventDetails::where('master_id', $event->id)->get(); $i=0;
                        @endphp
                        @foreach ($eventDetails as $detail)
                          @php
                            $footages  = App\Models\BackEnd\FootageBackup::where('event_details_id', $detail->id)->get();
                        @endphp
                            <h4 class="text-center mt-5 mb-2">Event-{{++$i}} : {{ $detail->type->type_name }}</h4>
                            <div class="form-group row p-3">
                                <label class="col-sm-2 p-1">Event Shift</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->shift->shift_name }}
                                </div>
                                <label class="col-sm-2 p-1">Date</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->date }}
                                </div>
                                <label class="col-sm-2 p-1">Time</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    @php $time =date('g:i a',strtotime($detail->start_time)).' - '.date('g:i a',strtotime($detail->end_time))  @endphp
                                    {{ $time }}
                                </div>
                                <label class="col-sm-2 p-1">District</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->district->district }}
                                </div>
                                <label class="col-sm-2 p-1">Venue</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->venue }}
                                </div>
                                <label class="col-sm-2 p-1">Package</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->category->category_name }}
                                </div>
                                <label class="col-sm-2 p-1">Package Details</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->package->name }}
                                </div>
                                <!--<label class="col-sm-2 p-1">Price</label>-->
                                <!--<label class="col-sm-1 p-1">:</label>-->
                                <!--<div class="col-md-3 p-1">-->
                                <!--    {{ $detail->package_price ? $detail->package_price: $detail->package->discount  }}-->
                                <!--</div>-->
                                @if ($detail->transportation != null || $detail->accomodation != null || $detail->shift_charge != null)
                                    <label class="col-sm-2 p-1">Transportation</label>
                                    <label class="col-sm-1 p-1">:</label>
                                    <div class="col-md-3 p-1">
                                        {{ $detail->transportation }}
                                    </div>
                                    <label class="col-sm-2 p-1">Accomodation</label>
                                    <label class="col-sm-1 p-1">:</label>
                                    <div class="col-md-3 p-1">
                                        {{ $detail->accomodation }}
                                    </div>
                                    <label class="col-sm-2 p-1">Shift Charge</label>
                                    <label class="col-sm-1 p-1">:</label>
                                    <div class="col-md-3 p-1">
                                        {{ $detail->shift_charge }}
                                    </div>
                                    <label class="col-sm-2 p-1">Total Price</label>
                                    <label class="col-sm-1 p-1">:</label>
                                    <div class="col-md-3 p-1">
                                        {{ $detail->package_price }}
                                    </div>
                                @endif
                                @if($detail->add_ons)
                                <label class="col-sm-2 p-1">Add Ons</label>
                                    <label class="col-sm-1 p-1">:</label>
                                    <div class="col-md-3 p-1">
                                        {{ $detail->add_ons }}
                                    </div>
                                @endif
                                @if(count($footages)>0)
                                <h4 class="mt-3 mt-5 text-center">Footage Backup</h4>
                                @foreach($footages as $footage)
                                    <div class="col-md-12 p-1 text-center">
                                        <br>{{ $footage->footage_backup }}
                                    </div>
                                @endforeach
                                @endif
                                @if($detail->photo_selection ||$detail->video_selection)<h4 class="mt-3 mt-5 text-center">Client Selections </h4> @endif
                                @if($detail->photo_selection)
                                <label class="col-sm-2 p-1 mt-3">Photo Selection</label>
                                <label class="col-sm-1 p-1 mt-3">:</label>
                                <div class="col-md-9 p-1 mt-3">
                                    {!! $detail->photo_selection !!}<br>
                                </div>
                                @endif
                                @if($detail->video_selection)
                                <label class="col-sm-2 p-1">Video Selection</label>
                                <label class="col-sm-1 p-1">:</label>
                                <div class="col-md-3 p-1">
                                    {{ $detail->video_selection }}
                                </div>
                                @endif
                            </div>
                            @php $user = App\Models\BackEnd\EventDetailsLog::where('event_details_id',$detail->id)->get(); @endphp
                            @if(count($user)>0)
                            <h4 class="mt-3 mb-2 text-center">Assigned User</h4>
                            <h5 id="delteMessage"></h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <table class="table table-bordered table-hover" id="assignUserTable" >
                                        <thead>
                                            <tr>
                                                <th class="p-3">Name</th>
                                                <th class="p-3">Email</th>
                                                <th class="p-3">Mobile No.</th>
                                                <th class="p-3">Position</th>
                                                <th class="p-3">Category</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            @foreach($user as $v_user)
                                            <tr data-id="{{ $v_user->id}}">
                                                <td class="p-3">{{$v_user->user->name}}</td>
                                                <td class="p-3">{{$v_user->user->email}}</td>
                                                <td class="p-3">{{$v_user->user->phone}}</td>
                                                <td class="p-3">
                                                    @if($v_user->status==1) Photographer
                                                    @elseif($v_user->status==2) Cinematographer
                                                    @elseif($v_user->status==3) Photo Editor
                                                    @else Cine Editor
                                                    @endif
                                                </td>
                                                <td class="p-3">{{$v_user->user->category}}</td>
                                                 <td>
                                                    <a 
                                                    onclick="deleteassignUser('{{ $v_user->id }}')" 
                                                    data-id="{{ $v_user->id  }}" 
                                                    href="javascript:void(0);"
                                                    class="btn btn-danger delete">
                                                    <i class="fa fa-minus"></i>
                                                </a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            @endif
                        @endforeach
                      
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-sm btn-primary" data-bs-dismiss="modal">Update</button>
                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">close</button>
                    </div>
                </div>
            </div>
        </div>
        
        @php
            $activity_logs = App\Models\ActivityLog::where('master_id', $event->id)->get();
        @endphp
        <div class="modal fade activity_log-{{ $event->id }}" id="" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl ">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h3 class="text-white">Activity Log</h3>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered table-hover log-table">
                                    <thead>
                                        <tr>
                                            <th class="p-3" width="5%">Edited Date</th>
                                            <th class="p-3" width="90%">Activity Log</th>
                                            <th class="p-3" width="5%">Created By</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <style>
                                            td.p-3.new-td {
                                                    overflow: hidden;
                                                    text-overflow: ellipsis;
                                                    white-space: normal; 
                                                    max-height: 500px;
                                                    width: 100%;
                                                    display: -webkit-box;
                                                    -webkit-line-clamp: 3;
                                                    }
                                        </style>
                                        @foreach($activity_logs as $v_log)
                                        <tr>
                                            <td class="p-3" width="5%">{{ $v_log->created_at->todatestring() }}</td>
                                            <td class="p-3 new-td" >{!! $v_log->log !!}</td>
                                            <td class="p-3" width="5%">@if($v_log->user){{ $v_log->user->name }}@endif</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>

                                
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <!--<button type="submit" class="btn btn-sm btn-primary" data-bs-dismiss="modal">Update</button>-->
                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bg-dark photographer-{{ $event->id }}" id="photographer-{{ $event->id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h2 class="text-white text-center">Assign photographer</h2>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                        
                    </div>
                    <form action="{{ route('assignEvent') }}" method="POST" id="photographerAssignForm-{{ $event->id }}" data-id="{{ $event->id}}">
                        @csrf
                        <div class="modal-body">
                            <div id="message-photographer-{{ $event->id}}" class="mt-3 border-1 p-2">

                            </div>
                            @php  $i = 0; @endphp
                            @foreach ($eventDetails as $detail)
                             @if($detail->status != '0' && $detail->status != '2' )
                                @php
                                    $i++;
                                    $assignPhotographer = App\Models\BackEnd\EventDetailsLog::where('event_details_id', $detail->id)->get();
                                @endphp

                                <div class="row-col-12">
                                    <h4 class="text-center mt-3 mb-4"> {{ $detail->type->type_name }}</h4>
                                </div>
                                <div class="form-group row pb-3">
                                    <div class="col-md-6">
                                        <strong>Event Date :</strong> {{ $detail->date }}<br>
                                        <strong class="mb-2">Event Time :</strong>
                                        {{ date('g:i a', strtotime($detail->start_time)) . ' - ' . date('g:i a', strtotime($detail->end_time)) }}<br>
                                        <strong class="mb-2">Event District :</strong>{{ $detail->district->district }}<br>
                                        <strong class="mb-2">Event Location :</strong>{{ $detail->venue }}<br>
                                    </div>
                                    <div class="col-md-6">
                                        <strong class="mb-2">Package :</strong> {{ $detail->category->category_name }}<br>
                                        <strong class="mb-2">Package Details :</strong> {{ $detail->package->name }}<br>
                                        <strong class="mb-2">Package Amount :</strong> {{ $detail->package->discount }}<br>
                                    </div>
                                </div>
                                <div class="form-group row pb-3">
                                    @if (
                                        $assignPhotographer->contains('event_details_id', $detail->id) &&
                                            in_array('1', $assignPhotographer->pluck('status')->toArray()))
                                        <div class="col-md-12">
                                            <strong> Assigned Photographer:</strong>
                                            @foreach ($assignPhotographer as $photographer)
                                                @if ($photographer->event_details_id == $detail->id && $photographer->status == 1)
                                                    {{ $photographer->user->name }},
                                                @endif
                                            @endforeach
                                        </div>
                                    @else
                                        <label class="col-sm-3">Select Photographer</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-6">
                                            <input type="hidden" name="status" value="1">
                                            <select name="user[{{ $detail->id }}][{{ $i }}]"
                                                class="form-control" id="userId-{{ $detail->id }}"
                                                onchange="filterCategory(this,{{ $detail->id }})">
                                                <option selected disabled>Choose Photographer..</option>
                                                @foreach ($users as $p_user)
                                                    @php
                                                        $positions = json_decode($p_user->position);
                                                    @endphp
                                                    @if ($positions && in_array('Photographer', $positions))
                                                        <option value="{{ $p_user->id }}{{ $p_user->category }}">
                                                            {{ $p_user->name }}-{{ $p_user->category }}-{{ $p_user->experience_level }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif
                                    <div class="hide" id="hideDiv1-{{ $detail->id }}">
                                        <div class="form-group row pb-3 mt-3">
                                            <label class="col-sm-3">Amount</label>
                                            <label class="col-sm-1">:</label>
                                            <div class="col-sm-7">
                                                <input type="text" name="payment[{{ $detail->id }}][{{ $i }}]" id="payment{{ $detail->id }}"
                                                    class="form-control payment" value="" placeholder="Type Amount">
                                            </div>
                                        </div>
                                        {{-- <div class="form-group row pb-3">
                                            <label class="col-sm-3">Advance</label>
                                            <label class="col-sm-1">:</label>
                                            <div class="col-sm-7">
                                                <input type="text" name="advance[{{ $detail->id }}][{{ $i }}]" id="advance{{ $detail->id }}"
                                                    class="form-control advance" value="" placeholder="Advance" onkeyup="calculateDueAmount(this)">
                                            </div>
                                        </div>
                                        <div class="form-group row pb-3">
                                            <label class="col-sm-3">Due</label>
                                            <label class="col-sm-1">:</label>
                                            <div class="col-sm-7">
                                                <input type="text" name="due[{{ $detail->id }}][{{ $i }}]" id="due{{ $detail->id }}"
                                                    class="form-control due" value="" placeholder="Due">
                                            </div>
                                        </div> --}}
                                    </div>
                                    <div id="photographer-wrapper{{ $detail->id }}">
                                    </div>

                                </div>

                                <button type="button" class="col-sm-2 btn btn-success add mt-2"
                                    id="addpt-{{ $detail->id }}" onclick="addMore(this)">+ Add More
                                </button>
                                    @endif
                            @endforeach
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade bg-dark cinematographer-{{ $event->id }}" id="cinematographer-{{ $event->id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h2 class="text-white text-center">Assign Cinematographer</h2>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <form action="{{ route('assignEvent') }}" method="POST"  id="cinematographerAssignForm-{{ $event->id }}" data-id="{{ $event->id}}">
                        @csrf
                        <div class="modal-body">
                             <div id="message-cinematographer-{{ $event->id}}" class="mt-3 border-1 p-2">

                            </div>
                            @php $j= 0; @endphp
                            @foreach ($eventDetails as $c_detail)
                            @if($c_detail->status != '0' && $c_detail->status != '2' )
                                @php
                                    $j++;
                                    $assignCinematographer = App\Models\BackEnd\EventDetailsLog::where('event_details_id', $c_detail->id)->get();
                                @endphp
                                <input type="hidden" name="status" value="2">
                                <div class="row-col-12">
                                    <h4 class="text-center mt-3 mb-4"> {{ $c_detail->type->type_name }}</h4>
                                </div>
                                <div class="form-group row pb-3">
                                    <div class="col-md-6">
                                        <strong>Event Date :</strong> {{ $c_detail->date }}<br>
                                        <strong>Event Time :</strong>
                                        {{ date('g:i a', strtotime($c_detail->start_time)) . ' - ' . date('g:i a', strtotime($c_detail->end_time)) }}<br>
                                        <strong class="mb-3">Event District :</strong>{{ $c_detail->district->district }}<br>
                                        <strong class="mb-3">Event Location :</strong>{{ $c_detail->venue }}<br>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Package :</strong> {{ $c_detail->category->category_name }}<br>
                                        <strong>Package Details :</strong> {{ $c_detail->package->name }}<br>
                                        <strong>Package Amount :</strong> {{ $c_detail->package->discount }}<br>
                                    </div>
                                </div>
                                <div class="form-group row pb-3">
                                    @if (
                                        $assignCinematographer->contains('event_details_id', $c_detail->id) &&
                                            in_array('2', $assignCinematographer->pluck('status')->toArray()))
                                        <div class="col-md-12">
                                            <strong> Assigned Cinematographer:</strong>
                                            @foreach ($assignCinematographer as $cinematographer)
                                                @if ($cinematographer->event_details_id == $c_detail->id && $cinematographer->status == 2)
                                                    {{ $cinematographer->user->name }},
                                                @endif
                                            @endforeach
                                        </div>
                                    @else
                                        <label class="col-sm-3">Select Cinematographer</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-6">
                                            <select name="user[{{ $c_detail->id }}][{{ $j }}]"
                                                class="form-control" id="userId-{{ $c_detail->id }}"
                                                onchange="filterCategory(this,{{ $c_detail->id }})">
                                                <option selected disabled>Choose Cinematographer..</option>
                                                @foreach ($users as $c_user)
                                                    @php
                                                        $positions = json_decode($c_user->position);
                                                    @endphp
                                                    @if ($positions && in_array('Cinematographer', $positions))
                                                        <option value="{{ $c_user->id }}{{ $c_user->category }}">
                                                            {{ $c_user->name }}-{{ $c_user->category }}-{{ $c_user->experience_level }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif
                                <div class="hide" id="hideDiv2-{{ $c_detail->id }}">
                                    <div class="form-group row pb-3">
                                        <label class="col-sm-3">Amount</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="payment[{{ $c_detail->id }}][{{ $j }}]" id="payment"
                                                class="form-control" value="" placeholder="Type Amount">
                                        </div>
                                    </div>
                                    {{-- <div class="form-group row pb-3">
                                        <label class="col-sm-3">Advance</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="advance[{{ $c_detail->id }}]" id="advance"
                                                class="form-control" value="" placeholder="Advance">
                                        </div>
                                    </div>
                                    <div class="form-group row pb-3">
                                        <label class="col-sm-3">Due</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="due[{{ $c_detail->id }}]" id="due"
                                                class="form-control" value="" placeholder="Due">
                                        </div>
                                    </div> --}}
                                </div>

                                <div id="cinematographer-wrapper{{ $c_detail->id }}">
                                </div>
                        </div>
                        <button type="button" class="col-sm-2 btn btn-success add"
                        id="addct-{{ $c_detail->id }}" onclick="addMore(this)">+ Add More</button>
                        @endif
                            @endforeach
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
        <div class="modal fade bg-dark photoeditor-{{ $event->id }}" id="photoEditor-{{ $event->id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h2 class="text-white text-center">Assign Photo Editor</h2>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <form action="{{ route('assignEvent') }}" method="POST"  id="photoEditorAssignForm-{{ $event->id }}" data-id="{{ $event->id}}">
                        @csrf
                        <input type="hidden" name="status" value="3">
                        <div class="modal-body">
                             <div id="message-photoEditor-{{ $event->id}}" class="mt-3 border-1 p-2">

                            </div>
                            @foreach ($eventDetails as $pE_detail)
                            @php $k = 0; @endphp
                            @if($pE_detail->status != '0' && $pE_detail->status != '2' )
                                @php
                                    ++$k;
                                    $assignPhotoEditors = App\Models\BackEnd\EventDetailsLog::where('event_details_id', $pE_detail->id)->get();
                                @endphp
                                <div class="row-col-12">
                                    <h4 class="text-center mt-3 mb-4"> {{ $pE_detail->type->type_name }}</h4>
                                </div>
                                <div class="form-group row pb-3">
                                    <div class="col-md-6">
                                        <strong>Event Date :</strong> {{ $pE_detail->date }}<br>
                                        <strong>Event Time :</strong>
                                        {{ date('g:i a', strtotime($pE_detail->start_time)) . ' - ' . date('g:i a', strtotime($pE_detail->end_time)) }}<br>
                                        <strong class="mb-3">Event District :</strong>{{ $pE_detail->district->district }}<br>
                                        <strong class="mb-3">Event Location :</strong>{{ $pE_detail->venue }}<br>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Package :</strong> {{ $pE_detail->category->category_name }}<br>
                                        <strong>Package Details :</strong> {{ $pE_detail->package->name }}<br>
                                    </div>
                                </div>
                                <div class="form-group row pb-3">
                                    @if (
                                        $assignPhotoEditors->contains('event_details_id', $pE_detail->id) &&
                                            in_array('3', $assignPhotoEditors->pluck('status')->toArray()))
                                        <div class="col-md-12">
                                            <strong> Assigned Photo Editor:</strong>
                                            @foreach ($assignPhotoEditors as $p_editor)
                                                @if ($p_editor->event_details_id == $pE_detail->id && $p_editor->status == 3)
                                                    {{ $p_editor->user->name }},
                                                @endif
                                            @endforeach
                                        </div>
                                    @else
                                        <label class="col-sm-3">Select Photo Editor</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-6">
                                            <select name="user[{{ $pE_detail->id }}][{{ $k }}]"
                                                class="form-control" id="userId-{{ $pE_detail->id }}"
                                                onchange="filterCategory(this,{{ $pE_detail->id }})">
                                                <option selected disabled>Choose Photo Editor..</option>
                                                @foreach ($users as $pE_user)
                                                    @php
                                                        $positions = json_decode($pE_user->position);
                                                    @endphp
                                                    @if ($positions && in_array('Photo Editor', $positions))
                                                        <option value="{{ $pE_user->id }}{{ $pE_user->category }}">
                                                            {{ $pE_user->name }}-{{ $pE_user->category }}-{{ $pE_user->experience_level }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif
                                    <button type="button" class="col-sm-2 btn btn-success add"
                                        id="addpE-{{ $pE_detail->id }}" onclick="addMore(this)">+ Add More</button>
                                </div>
                                <div class="hide" id="hideDiv3-{{ $pE_detail->id }}">
                                    <div class="form-group row pb-3">
                                        <label class="col-sm-3">Amount</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="payment[{{ $pE_detail->id }}][{{ $k }}]" id="payment"
                                                class="form-control" value="" placeholder="Type Amount">
                                        </div>
                                    </div>
                                </div>
                                <div id="photoEditor-wrapper{{ $pE_detail->id }}">
                                </div>
                                @endif
                            @endforeach
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade bg-dark cineeditor-{{ $event->id }}" id="cineEditor-{{ $event->id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h2 class="text-white text-center">Assign Cine Editor</h2>
                        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                    </div>
                    <form action="{{ route('assignEvent') }}" method="POST"  id="cineEditorAssignForm-{{ $event->id }}" data-id="{{ $event->id}}">
                        @csrf
                        <input type="hidden" name="status" value="4">
                        <div class="modal-body">
                             <div id="message-cineEditor-{{ $event->id}}" class="mt-3 border-1 p-2">

                            </div>
                            @php $l=0; @endphp
                            @foreach ($eventDetails as $cE_detail)
                            @if($cE_detail->status != '0' && $cE_detail->status != '2' )
                                @php
                                    ++$l;
                                    $assignCineEditor = App\Models\BackEnd\EventDetailsLog::where('event_details_id', $cE_detail->id)->get();
                                @endphp
                                <div class="row-col-12">
                                    <h4 class="text-center mt-3 mb-4"> {{ $cE_detail->type->type_name }}</h4>
                                </div>
                                <div class="form-group row pb-3">
                                    <div class="col-md-6">
                                        <strong>Event Date :</strong> {{ $cE_detail->date }}<br>
                                        <strong>Event Time :</strong>
                                        {{ date('g:i a', strtotime($cE_detail->start_time)) . ' - ' . date('g:i a', strtotime($cE_detail->end_time)) }}<br>
                                        <strong class="mb-3">Event District :</strong>{{ $cE_detail->district->district }}<br>
                                        <strong class="mb-3">Event Location :</strong>{{ $cE_detail->venue }}<br>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Package :</strong> {{ $cE_detail->category->category_name }}<br>
                                        <strong>Package Details :</strong> {{ $cE_detail->package->name }}<br>
                                    </div>
                                </div>
                                <div class="form-group row pb-3">
                                    @if (
                                        $assignPhotoEditors->contains('event_details_id', $cE_detail->id) &&
                                            in_array('4', $assignPhotoEditors->pluck('status')->toArray()))
                                        <div class="col-md-12">
                                            <strong> Assigned Cine Editor:</strong>
                                            @foreach ($assignPhotoEditors as $c_editor)
                                                @if ($c_editor->event_details_id == $cE_detail->id && $c_editor->status == 4)
                                                    {{ $c_editor->user->name }},
                                                @endif
                                            @endforeach
                                        </div>
                                    @else
                                        <label class="col-sm-3">Select Cine Editor</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-6">
                                            <select name="user[{{ $cE_detail->id }}][{{ $l }}]"
                                                class="form-control" id="userId-{{ $cE_detail->id }}"
                                                onchange="filterCategory(this,{{ $cE_detail->id }})">
                                                <option selected disabled>Choose Cine Editor..</option>
                                                @foreach ($users as $cE_user)
                                                    @php
                                                        $positions = json_decode($cE_user->position);
                                                    @endphp
                                                    @if ($positions && in_array('Cine Editor', $positions))
                                                        <option value="{{ $cE_user->id }}{{ $cE_user->category }}">
                                                            {{ $cE_user->name }}-{{ $cE_user->category }}-{{ $cE_user->experience_level }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif
                                    <button type="button" class="col-sm-2 btn btn-success add"
                                        id="addcE-{{ $cE_detail->id }}" onclick="addMore(this)">+ Add More</button>
                                </div>
                             
                                <div class="hide" id="hideDiv4-{{ $cE_detail->id }}">
                                    <div class="form-group row pb-3">
                                        <label class="col-sm-3">Amount</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="payment[{{ $cE_detail->id }}][{{ $l }}]" id="payment"
                                                class="form-control" value="" placeholder="Type Amount">
                                        </div>
                                    </div>
                                    {{-- <div class="form-group row pb-3">
                                        <label class="col-sm-3">Advance</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="advance[{{ $cE_detail->id }}]" id="advance"
                                                class="form-control" value="" placeholder="Advance">
                                        </div>
                                    </div>
                                    <div class="form-group row pb-3">
                                        <label class="col-sm-3">Due</label>
                                        <label class="col-sm-1">:</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="due[{{ $cE_detail->id }}]" id="due"
                                                class="form-control" value="" placeholder="Due">
                                        </div>
                                    </div> --}}
                                </div>
                                <div id="cineEditor-wrapper{{ $cE_detail->id }}">
                                </div>
                                @endif
                            @endforeach
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endforeach
     <style>
        .danger{
            background: rgb(218, 164, 164);
        }
        .warning{
            background: rgb(233, 233, 158);
        }
        .success{
            background: #79eb8f;
        }
        
    </style>
@endsection

@section('js')


<script type="text/javascript">
     
           $(document).ready(function (){
                load_data();  
             $('#selectionTable').hide();
             
                function load_data(status = "", payment_status="", event = "", district = "", type = "", shift = "", category = "",
                    package = "", from_date = "", to_date = "") {
                        var table;
                        if(status == 4  ){
                              $('#eventTable').hide(); // Hide the first table
                             $('#selectionTable').show();
                            if (!$.fn.DataTable.isDataTable('#selectionTable')) {
                                table = $('#selectionTable').DataTable({
                                     processing: true,
                                    serverSide: true,
                                    deferRender: true,
                                    responsive: true,
                                    bLengthChange: false,
                                    searchDelay: 500,
                                    pageLength: 10,
                                    ajax: {
                                        url: '{!! route('allEvent') !!}',
                                        data: {
                                            status: status,
                                            payment_status: payment_status,
                                            event: event,
                                            district: district,
                                            type: type,
                                            shift: shift,
                                            category: category,
                                            package: package,
                                            from_date: from_date,
                                            to_date: to_date
                                        }
                                    },
                                    columns: [
                                        { data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false, orderable: false },
                                        { data: 'selection_date', name: 'selection_date' },
                                        { data: 'delivery_date', name: 'delivery_date' },
                                        { data: 'booking_id', name: 'booking_id' },
                                        { data: 'booking_info', name: 'booking_info' },
                                        { data: 'action', name: 'action' },
                                        { data: 'add_new', name: 'add_new' },
                                        { data: 'expense', name: 'expense' },
                                        { data: 'status', name: 'status' },
                                        { data: 'payment_info', name: 'payment_info' },
                                        { data: 'assign', name: 'assign' },
                                        { data: 'event_type', name: 'event_type' },
                                        { data: 'event_date', name: 'event_date' },
                                        { data: 'event_shift', name: 'event_shift' },
                                        { data: 'event_time', name: 'event_time' },
                                        { data: 'package', name: 'package' },
                                        { data: 'package_name', name: 'package_name' },
                                          { data: 'experience', name: 'experience' },
                                        
                                    ],
                                     "createdRow": function(row, data, dataIndex) {
                                        var deliveryDate = new Date(data['delivery_date']);
                                        var currentDate = new Date();
                                        var diff = deliveryDate - currentDate;
                                        var diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
                                        
                                        if (diffDays < 0 || diffDays < 7) {
                                            $(row).addClass('danger'); 
                                        } else if (diffDays < 45) {
                                            $(row).addClass('warning'); 
                                        }
                                    },
                                    "scrollY": "400px",
                                    "scrollCollapse": true
                                });
                            }
                        }else{
                            $('#selectionTable').hide();
                            $('#eventTable').show(); // Hide the first table
                            if (!$.fn.DataTable.isDataTable('#eventTable')) {
                                var table = $('#eventTable').DataTable({
                                     processing: true,
                                    serverSide: true,
                                    deferRender: true,
                                    responsive: true,
                                    bLengthChange: false,
                                    searchDelay: 500,
                                    pageLength: 10,
                                    ajax: {
                                        url: '{!! route('allEvent') !!}',
                                        data: {
                                            status: status,
                                            payment_status: payment_status,
                                            event: event,
                                            district: district,
                                            type: type,
                                            shift: shift,
                                            category: category,
                                            package: package,
                                            from_date: from_date,
                                            to_date: to_date
                                        }
                                    },
                                    columns: [
                                        { data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false, orderable: false },
                                        { data: 'booking_id', name: 'booking_id' },
                                        { data: 'event_date', name: 'event_date' },
                                        { data: 'booking_info', name: 'booking_info' },
                                        { data: 'action', name: 'action' },
                                        { data: 'add_new', name: 'add_new' },
                                        { data: 'status', name: 'status' },
                                         { data: 'payment_info', name: 'payment_info' },
                                        { data: 'assign', name: 'assign' },
                                         { data: 'expense', name: 'expense' },
                                        { data: 'event_type', name: 'event_type' },
                                        { data: 'selection_date', name: 'selection_date' },
                                        { data: 'event_shift', name: 'event_shift' },
                                        { data: 'event_time', name: 'event_time' },
                                        { data: 'package', name: 'package' },
                                        { data: 'package_name', name: 'package_name' },
                                         { data: 'experience', name: 'experience' },
                                        { data: 'delivery_date', name: 'delivery_date' },
                                       
                                    ],
                                    "createdRow": function(row, data, dataIndex) {
                                        if (data['master_status'] == 2) { // Check if the event master status is 2
                                                $(row).addClass('success'); // Apply green color to rows where event master status is 2
                                            }

                                        if (data['delivery_date'] != null && data['delivery_date'] != '') {
                                            var deliveryDate = new Date(data['delivery_date']);
                                            var currentDate = new Date();
                                            var diff = deliveryDate - currentDate;
                                            var diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));
                                            if (diffDays < 0 || diffDays < 7) {
                                                $(row).addClass('danger'); 
                                            } else if (diffDays < 45) {
                                                $(row).addClass('warning'); 
                                            }
                                        }
                                            
                                    },
                                     "scrollY": "500px",
                                     "scrollX": true,
                                    "scrollCollapse": true,
                                    
                                });
                            }
                        }
                    // if (!$.fn.DataTable.isDataTable('#eventTable')) {
                    //     var table = $('#eventTable').DataTable({
                    //         processing: true,
                    //         serverSide: true,
                    //         ajax:{
                    //             url: '{!! route('allEvent') !!}' ,
                    //             data: {
                    //                 status: status,
                    //                 payment_status: payment_status,
                    //                 event: event,
                    //                 district: district,
                    //                 type: type,
                    //                 shift: shift,
                    //                 category: category,
                    //                 package: package,
                    //                 from_date: from_date,
                    //                 to_date: to_date
                    //             }
                    //         } ,
                           
                    //         columns: [{
                    //                 data: 'DT_RowIndex',
                    //                 name: 'DT_RowIndex',
                    //                 searchable: false,
                    //                 orderable: false
                    //             },
                    //             {
                    //                 data: 'booking_id',
                    //                 name: 'booking_id'
                    //             },
                    //             {
                    //                 data: 'booking_info',
                    //                 name: 'booking_info'
                    //             },
                    //             {
                    //                 data: 'action',
                    //                 name: 'action'
                    //             },
                    //             {
                    //                 data: 'add_new',
                    //                 name: 'add_new'
                    //             },
                    //             {
                    //                 data: 'status',
                    //                 name: 'status'
                    //             },
                    //             {
                    //                 data: 'assign',
                    //                 name: 'assign'
                    //             },
                    //             {
                    //                 data: 'event_type',
                    //                 name: 'event_type'
                    //             },
                    //             {
                    //                 data: 'event_date',
                    //                 name: 'event_date'
                    //             },
                    //             {
                    //                 data: 'event_shift',
                    //                 name: 'event_shift'
                    //             },
                    //             {
                    //                 data: 'event_time',
                    //                 name: 'event_time'
                    //             },
                    //             {
                    //                 data: 'package',
                    //                 name: 'package'
                    //             },
                    //             {
                    //                 data: 'package_name',
                    //                 name: 'package_name'
                    //             },
                    //             {
                    //                 data: 'payment_info',
                    //                 name: 'payment_info'
                    //             }
                    //         ],
                    //         "scrollY": "400px",
                    //         "scrollCollapse": true
                    //     });
                    // }
                }
                $('#filter').click(function () {
                    var status = document.getElementById('status').value;
                    var payment_status = document.getElementById('payment_status').value;
                    var event = document.getElementById('filter-event').value;
                    var district = document.getElementById('district').value;
                    var type = document.getElementById('type').value;
                    var shift = document.getElementById('shift').value;
                    var category = document.getElementById('category').value;
                    var package = document.getElementById('package').value;
                    var from_date = document.getElementById('from-date').value;
                    var to_date = document.getElementById('to-date').value;
                    var loading = "<img src='{{ asset('frontend/images/loading.gif') }}'>";
                    // $("#show").html(loading);
                    $('#loadingIndicator').show();
                    var urldata = '{!! route('allEvent') !!}';
                    $.ajax({
                    type: "GET",
                    url: urldata,
                    data: {
                        status,
                        payment_status,
                        event,
                        district,
                        type,
                        shift,
                        category,
                        package,
                        from_date,
                        to_date
                    },
                    success: function(data) {
                        $('#loadingIndicator').show();
                          $('#selectionTable').DataTable().destroy();
                            $('#eventTable').DataTable().destroy();
                        load_data(status,payment_status, event, district,type,shift,category,package,from_date,to_date)
                    $(".chosen-select").chosen();
                    }
                });
            });
            
        });
           
    </script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
   
<script>

</script>

    <script>
        var t = 1;
        function addMore(e) {
            const text = e.id;
            const pId = text.replace('addpt-', '');
            const cId = text.replace('addct-', '');
            console.log(cId);
            const pEId = text.replace('addpE-', '');
            const cEId = text.replace('addcE-', '');
            t++;
            $('#photographer-wrapper' + pId).append(`
                <div class="col-md-12  mt-3">
                    <div class="form-group row pb-3">
                        <input type="hidden" name="status" value="1">
                                <label class="col-sm-3 ">Other Photographer</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <select name="user[` + pId + `][` + t + `]" class="form-control" id="userId-` +
                                    pId + `" onchange="filterAppendCategory(this,` + pId + `,` + t + `)">
                                        <option selected disabled>Choose Photographer..</option>
                                    @foreach ($users as $p_user)
                                        @php
                                            $positions = json_decode($p_user->position);
                                        @endphp
                                        @if ($positions && in_array('Photographer', $positions))
                                            <option value="{{ $p_user->id }}{{ $p_user->category }}">{{ $p_user->name }}-{{ $p_user->category }}-{{ $p_user->experience_level }}</option>
                                        @endif
                                    @endforeach
                                </select>  
                                </div>
                            </div>
                            <div class="hide" id="append1-` + pId + `` + t + `">
                                <div class="form-group row pb-3">
                                    <label  class="col-sm-3">Amount</label>
                                    <label  class="col-sm-1">:</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="payment[` + pId + `][`+ t +`]" id="payment[` + pId + `]" class="form-control" value="" placeholder="Type Amount">
                                    </div>
                                </div>
                            </div>
                            <span class="remove btn btn-danger text-center" style="width: fit-content; margin-bottom:12px"><i class="fa fa-times"></i></span>
                </div>`)

            // $('.chosen-select').chosen({
            //     search_contains: true,
            // });

            $('#photographer-wrapper' + pId).on('click', '.remove', function() {
                $(this).parent().remove();
            });

            $('#cinematographer-wrapper' + cId).append(`
                <div class="col-md-12 mt-3">
                    <div class="form-group row pb-3 ">
                        <input type="hidden" name="status" value="2">
                                <label class="col-sm-3 ">Other Cinematographer</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <select name="user[` + cId + `][` + t + `]" class="form-control" id="userId-` +
                                    cId + `" onchange="filterAppendCategory(this,` + cId + `,` + t + `)">
                                        <option selected disabled>Choose Cinematographer..</option>
                                    @foreach ($users as $ct_user)
                                        @php
                                            $positions = json_decode($ct_user->position);
                                        @endphp
                                        @if ($positions && in_array('Cinematographer', $positions))
                                            <option value="{{ $ct_user->id }}{{ $ct_user->category }}">{{ $ct_user->name }}-{{ $ct_user->category }}-{{ $ct_user ->experience_level }}</option>
                                        @endif
                                    @endforeach
                                </select>  
                                </div>
                            </div>
                            <div class="hide" id="append2-` + cId + `` + t + `">
                            <div class="form-group row pb-3">
                                <label  class="col-sm-3">Amount</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <input type="text" name="payment[` + cId + `]" id="payment" class="form-control" value="" placeholder="Type Amount">
                                </div>
                            </div>
                           
                            </div>
                            <span class="remove btn btn-danger text-center" style="width: fit-content; margin-bottom:12px"><i class="fa fa-times"></i></span>
                </div>`)

            // $('.chosen-select').chosen({
            //     search_contains: true,
            // });

            $('#cinematographer-wrapper' + cId).on('click', '.remove', function() {
                $(this).parent().remove();
            });
            $('#photoEditor-wrapper' + pEId).append(`
                <div class="col-md-12  mt-3">
                    <div class="form-group row pb-3">
                        <input type="hidden" name="status" value="3">
                                <label class="col-sm-3 mt-3">Other Photo Editor</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <select name="user[` + pEId + `][` + t + `]" class="form-control" id="userId-` +
                                    pEId + `" onchange="filterAppendCategory(this,` + pEId + `,` + t + `)">
                                        <option selected disabled>Choose Photo Editor..</option>
                                    @foreach ($users as $pe_user)
                                        @php
                                            $positions = json_decode($pe_user->position);
                                        @endphp
                                        @if ($positions && in_array('Photo Editor', $positions))
                                            <option value="{{ $pe_user->id }}{{ $pe_user->category }}">{{ $pe_user->name }}-{{ $pe_user->category }}-{{ $pe_user ->experience_level }}</option>
                                        @endif
                                    @endforeach
                                </select>  
                                </div>
                            </div>
                            <div class="hide" id="append3-` + pEId + `` + t + `">
                            <div class="form-group row pb-3">
                                <label  class="col-sm-3">Amount</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <input type="text" name="payment[` + pEId + `][`+ t +`]" id="payment" class="form-control" value="" placeholder="Type Amount">
                                </div>
                            </div>
                            </div>
                            <span class="remove btn btn-danger text-center" style="width: fit-content; margin-bottom:12px"><i class="fa fa-times"></i></span>
                </div>`)

            // $('.chosen-select').chosen({
            //     search_contains: true,
            // });

            $('#photoEditor-wrapper' + pEId).on('click', '.remove', function() {
                $(this).parent().remove();
            });
            $('#cineEditor-wrapper' + cEId).append(`
                <div class="col-md-12  mt-3">
                    <div class="form-group row pb-3">
                        <input type="hidden" name="status" value="4">
                                <label class="col-sm-3 mt-3">Other Cine Editor</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <select name="user[` + cEId + `][` + t + `]" class="form-control" id="userId-` +
                                    cEId + `" onchange="filterAppendCategory(this,` + cEId + `,` + t + `)">
                                        <option selected disabled>Choose Cine Editor..</option>
                                    @foreach ($users as $ce_user)
                                        @php
                                            $positions = json_decode($ce_user->position);
                                        @endphp
                                        @if ($positions && in_array('Cine Editor', $positions))
                                            <option value="{{ $ce_user->id }}{{ $ce_user->category }}">{{ $ce_user->name }}-{{ $ce_user->category }}-{{ $ce_user ->experience_level }}</option>
                                        @endif
                                    @endforeach
                                </select>  
                                </div>
                            </div>
                            <div class="hide" id="append4-` + cEId + `` + t + `">
                            <div class="form-group row pb-3">
                                <label  class="col-sm-3">Amount</label>
                                <label  class="col-sm-1">:</label>
                                <div class="col-sm-6">
                                    <input type="text" name="payment[` + cEId + `][`+ t +`]" id="payment" class="form-control" value="" placeholder="Type Amount">
                                </div>
                            </div>
                            </div>
                            <span class="remove btn btn-danger text-center" style="width: fit-content; margin-bottom:12px"><i class="fa fa-times"></i></span>
                </div>`)

            // $('.chosen-select').chosen({
            //     search_contains: true,
            // });

            $('#cineEditor-wrapper' + cEId).on('click', '.remove', function() {
                $(this).parent().remove();
            });
        }
    </script>
    <script>
        function filterCategory(e, detailId) {
            $('#hideDiv1-' + detailId).hide();
            $('#hideDiv2-' + detailId).hide();
            $('#hideDiv3-' + detailId).hide();
            $('#hideDiv4-' + detailId).hide();
            var user_id = e.value;
            var parts = user_id.match(/^(\d+)([a-zA-Z]+)$/);
            var experienceLevel = parts[2];
            if (experienceLevel === 'Freelancer') {
                $('#hideDiv1-' + detailId).show();
                $('#hideDiv2-' + detailId).show();
                $('#hideDiv3-' + detailId).show();
                $('#hideDiv4-' + detailId).show();
            }
        }

        function filterAppendCategory(e, detail_id, serial) {
            $('#append1-' + detail_id + serial).hide();
            $('#append2-' + detail_id + serial).hide();
            $('#append3-' + detail_id + serial).hide();
            $('#append4-' + detail_id + serial).hide();
            var user_id = e.value;
            var parts = user_id.match(/^(\d+)([a-zA-Z]+)$/);
            var experienceLevel = parts[2];
            if (experienceLevel === 'Freelancer') {
                $('#append1-' + detail_id + serial).show();
                $('#append2-' + detail_id + serial).show();
                $('#append3-' + detail_id + serial).show();
                $('#append4-' + detail_id + serial).show();
                $('')
            }
        }
    </script>
    <script>
            function calculateDueAmount(e) {
                let text = e.id;
                let id = text.replace('advance', '');
                let totalAmount = parseFloat($('#payment'+id).val()) || 0;
                let advanceAmount = parseFloat($('#advance'+id).val()) || 0;
                let dueAmount = totalAmount - advanceAmount;
                $('#due'+id).val(dueAmount);
            }
    </script>
    <script>
        function filterEventData(){
            var status = document.getElementById('status').value;
            var event = document.getElementById('filter-event').value;
            var district = document.getElementById('district').value;
            var type = document.getElementById('type').value;
            var shift = document.getElementById('shift').value;
            var category = document.getElementById('category').value;
            var package = document.getElementById('package').value;
            var from_date = document.getElementById('from-date').value;
            var to_date = document.getElementById('to-date').value;
            var loading = "<img src='{{asset('frontend/images/loading.gif')}}'>";
		        $("#show").html(loading);
            var urldata = "{{route('filterEvent')}}";
            $.ajax({
                type: "GET",
                url: urldata,
                data: { status, event, district,type,shift,category,package,from_date,to_date},
                success: function (data) {
                    $("#show").html(data);
                    $(".chosen-select").chosen();
                }
            });
        }
    </script>
    
       <script>
        function deleteData(id) {
        if (confirm('Are you sure you want to delete this data?')) {
            $.ajax({
                url: '/event/delete/' + id,
                type: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    var table = $('#eventTable').DataTable();
                    var currentPage = table.page();
                        var rowToDelete = table.row($('.delete[data-id="' + id + '"]').closest('tr')); 
                        if (rowToDelete.length) { // Check if row exists before removal
                            rowToDelete.remove().draw();
                            if (currentPage > 0) {
                                table.page(currentPage).draw('page');
                            }
                        } else {
                            console.warn('Row with ID ' + id + ' not found in DataTable');
                        }
                },
                error: function(xhr) {
                    console.error('Error deleting data:', xhr.responseText);
                }
            });
        }
    }
        function deleteEvent(id) {
        if (confirm('Are you sure you want to delete this data?')) {
            $.ajax({
                url: '/event/delete/' + id,
                type: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    var table = $('#selectionTable').DataTable();
                    var currentPage = table.page();
                    var rowToDelete = table.row($('.delete[data-id="' + id + '"]').closest('tr'));
                    if (rowToDelete.length) { 
                        rowToDelete.remove().draw();
                        if (currentPage > 0) {
                                table.page(currentPage).draw('page');
                        }
                    } else {
                        console.warn('Row with ID ' + id + ' not found in DataTable');
                    }
                },
                error: function(xhr) {
                    console.error('Error deleting data:', xhr.responseText);
                }
            });
        }
    }
    </script>
    
      <script>  
        $(document).ready(function() {
          $('form[id^="status-form"]').submit(function(event) {
        event.preventDefault();
        var form = $(this);
        var id = form.data('id');

        $.ajax({
            url: '/event/status/' + id,
            type: 'put',
            data: {
                _token: '{{ csrf_token() }}', 
                status: form.find('select[name="status"]').val() 
            }
        })
        .done(function(response) {
            console.log('Data updated successfully');
            $.ajax({
                url: '/event/getAll', 
                type: 'get',
                success: function(data) {
                    var table = $('#eventTable').DataTable();
                    var currentPage = table.page();
                    table.clear().rows.add(data).draw();
                    if (currentPage > 0) {
                         table.page(currentPage).draw('page');
                    }
                },
                error: function(xhr) {
                    console.error('Error fetching updated data:', xhr.responseText);
                }
            });
            $('#successMessage_' + id).html('Data updated successfully').show();
            setTimeout(function() {
                $('#status_modal_' + id).modal('hide');
            }, 3000);
        })
        .fail(function(xhr) {
            console.error('Error updating data:', xhr.responseText);
        });
        });
    });
  
    </script>

<script>
     $(document).ready(function() {
        $('form[id^="shareExperinceForm"]').on('submit', function (e) {
        if (!e.isDefaultPrevented()) {
            e.preventDefault();
            var formData = $(this).serialize();
            var modalBody = $(this).closest('.modal-content').find('.modal-body');
            var id = $(this).data('id'); 
            console.log(id);
            $.ajax({
                url: $(this).attr('action'),
                type: 'POST',
                data: formData,
                dataType: 'json',
            })
            .done((response) => { 
                if (response.hasOwnProperty('message')) {
                    modalBody.find('#message-container-' + id).append('<p class="text-success text-center">' + response.message + '</p>');
                    setTimeout(function() {
                        $('#shareExperince-' + id).modal('hide');
                        $('#shareExperinceForm-' + id)[0].reset();
                        $('#shareExperince-'+ id).modal('show');
                    }, 3000);
                } else {
                    console.error('Unexpected response format:', response);
                }
            })
            .fail((xhr) => { 
                console.error('Error updating data:', xhr.responseText);
            });
        }
    });


    });

</script>


<script>
    
    $(document).ready(function() {
      $('form[id^="photographerAssignForm"]').submit(function(e) {
        e.preventDefault(); 
        var formData = $(this).serialize();
        var modalBody = $(this).closest('.modal-content').find('.modal-body');
        var id = $(this).data('id'); 
        $.ajax({
          url: $(this).attr('action'),
          type: 'POST',
          data: formData,
          dataType: 'json', 
        })
        .done((response) => { 
            if (response.hasOwnProperty('message')) {
                modalBody.find('#message-photographer-' + id).append('<p class="text-success text-center">' + response.message + '</p>');
                setTimeout(function() {
                    $('#photographer-' + id).modal('hide');
                    $('#photographerAssignForm-' + id)[0].reset();
                    $('#photographer-'+ id).modal('show');
                }, 3000);
            } else {
                console.error('Unexpected response format:', response);
            }
        })
        .fail((xhr) => { 
            console.error('Error updating data:', xhr.responseText);
        });
      });
    });
    </script>
    
    <script>
    
    $(document).ready(function() {
      $('form[id^="cinematographerAssignForm"]').submit(function(e) {
        e.preventDefault(); 
        var formData = $(this).serialize();
        var modalBody = $(this).closest('.modal-content').find('.modal-body');
        var id = $(this).data('id'); 
        $.ajax({
          url: $(this).attr('action'),
          type: 'POST',
          data: formData,
          dataType: 'json', 
        })
        .done((response) => { 
            if (response.hasOwnProperty('message')) {
                modalBody.find('#message-cinematographer-' + id).append('<p class="text-success text-center">' + response.message + '</p>');
                setTimeout(function() {
                    $('#cinematographer-' + id).modal('hide');
                    $('#cinematographerAssignForm-' + id)[0].reset();
                    $('#cinematographer-'+ id).modal('show');
                }, 3000);
            } else {
                console.error('Unexpected response format:', response);
            }
        })
        .fail((xhr) => { 
            console.error('Error updating data:', xhr.responseText);
        });
      });
    });
    
        </script>
        
         <script>
    
    $(document).ready(function() {
      $('form[id^="photoEditorAssignForm"]').submit(function(e) {
        e.preventDefault(); 
        var formData = $(this).serialize();
        var modalBody = $(this).closest('.modal-content').find('.modal-body');
        var id = $(this).data('id'); 
        $.ajax({
          url: $(this).attr('action'),
          type: 'POST',
          data: formData,
          dataType: 'json', 
        })
        .done((response) => { 
            if (response.hasOwnProperty('message')) {
                modalBody.find('#message-photoEditor-' + id).append('<p class="text-success text-center">' + response.message + '</p>');
                setTimeout(function() {
                    $('#photoEditor-' + id).modal('hide');
                    $('#photoEditorAssignForm-' + id)[0].reset();
                    $('#photoEditor-'+ id).modal('show');
                }, 3000);
            } else {
                console.error('Unexpected response format:', response);
            }
        })
        .fail((xhr) => { 
            console.error('Error updating data:', xhr.responseText);
        });
      });
    }); 
    
    $(document).ready(function() {
      $('form[id^="cineEditorAssignForm"]').submit(function(e) {
        e.preventDefault(); 
        var formData = $(this).serialize();
        var modalBody = $(this).closest('.modal-content').find('.modal-body');
        var id = $(this).data('id'); 
        $.ajax({
          url: $(this).attr('action'),
          type: 'POST',
          data: formData,
          dataType: 'json', 
        })
        .done((response) => { 
            if (response.hasOwnProperty('message')) {
                modalBody.find('#message-cineEditor-' + id).append('<p class="text-success text-center">' + response.message + '</p>');
                setTimeout(function() {
                    $('#cineEditor-' + id).modal('hide');
                    $('#cineEditorAssignForm-' + id)[0].reset();
                    $('#cineEditor-'+ id).modal('show');
                }, 3000);
            } else {
                console.error('Unexpected response format:', response);
            }
        })
        .fail((xhr) => { 
            console.error('Error updating data:', xhr.responseText);
        });
      });
    });
    </script>


<script>
     function deleteassignUser(id) {
        if (confirm('Are you sure you want to delete this data?')) {
            $.ajax({
                url: '/deleteAssignUser/' + id,
                type: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    var rowToDelete = document.querySelector('#assignUserTable tr[data-id="' + id + '"]');
                    if (rowToDelete) { 
                        rowToDelete.remove();
                        const messageElement = document.getElementById('success-message');
                        messageElement.textContent = 'User successfully deleted!';
                        messageElement.style.display = 'block';
                                                setTimeout(() => {
                            messageElement.style.display = 'none';
                        }, 3000); 
                    } else {
                        console.warn('Row with ID ' + id + ' not found in Table');
                    }
                },
                error: function(xhr) {
                    console.error('Error deleting data:', xhr.responseText);
                }
            });
        }
    }
</script>
    
    
@endsection
