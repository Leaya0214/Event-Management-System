@extends('BackEnd.master')
<style>
    table tbody td {
        padding-left: 25px !important;
        padding-top: 10px !important;
        font-size: 15px;
        color: rgba(20, 18, 18, 0.89);
    }
    table tbody td .description{
        text-align: center !important;
        align-items: center;
    }
</style>
@section('css')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
@endsection
@section('content')
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row  pr-3">
                    <div class="col-md-6">
                        <h6 class="card-title">Events</h6>
                        <p class="text-muted mb-3"></p>
                    </div>
                </div>
                <div class="table-responsive pt-3">
                    <table class="table table-striped table-bordered table-hover user_table" id="staffEventTable"  
                    style="width:100%; text-align:center;"  data-table="true">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event Type</th>
                                <th>Date</th>
                                <th>Shift</th>
                                <th>Time</th>
                                <th>District</th>
                                <th>Venue</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endsection

@section('js')

<script type="text/javascript">
    $(document).ready(function() {
        $('#staffEventTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '{{route('stuff.event.all')}}',
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    searchable: false,
                    orderable: false
                },
                {
                    data: 'event_type',
                    name: 'event_type'
                },
                {
                    data: 'date',
                    name: 'date'
                },
                {
                    data: 'event_shift',
                    name: 'event_shift'
                },
                {
                    data: 'time',
                    name: 'time'
                },
                {
                    data: 'district',
                    name: 'district'
                },
                {
                    data: 'venue',
                    name: 'venue'
                },
            ]
        });
    });

</script>
@endsection
