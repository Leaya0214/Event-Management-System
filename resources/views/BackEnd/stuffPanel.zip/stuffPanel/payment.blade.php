@extends('BackEnd.master')
<style>
    table tbody td {
        padding-left: 25px !important;
        padding-top: 10px !important;
        font-size: 15px;
        color: rgba(20, 18, 18, 0.89);
    }
    table tbody td .description{
        text-align: center !important;
        align-items: center;
    }
</style>
@section('css')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
@endsection
@section('content')
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row  pr-3">
                    <div class="col-md-6">
                        <h6 class="card-title">Events</h6>
                        <p class="text-muted mb-3"></p>
                    </div>
                </div>
                <div class="table-responsive pt-3">
                    <table class="table table-striped table-bordered table-hover user_table" id=""  
                    style="width:100%;"  data-table="true">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event Type</th>
                                <th>Date</th>
                                <th>Payment</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php 
                                $i = 1; 
                                $total = 0;
                            @endphp
                            @foreach($payments as $payment)
                            <tr>
                                <td>{{$i++}}</td>
                                <td>{{$payment->event_details->type->type_name}}</td>
                                <td>{{$payment->event_details->date}}</td>
                                <td>{{$payment->payment_amount}}</td>
                            </tr>
                            @php 
                                $total += $payment->payment_amount;
                            @endphp
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3"  class="text-end" >Total Payment :</th>   
                                <td>{{ $total}}</td>                            
                            </tr>
                            <tr >
                                <th colspan="3" class="text-end" >Paid :</th>
                                <td>{{$total_payment->paid}}</td>
                            </tr>
                            <tr>
                                <th colspan="3" class="text-end">Due :</th>
                                @php
                                    $due = $total - $total_payment->paid;
                                @endphp
                                <td>{{$due}}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    @endsection

@section('js')

<script type="text/javascript">
    $(document).ready(function() {
        $('#staffEventTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '{{route('stuff.payment.all')}}',
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    searchable: false,
                    orderable: false
                },
                {
                    data: 'event_type',
                    name: 'event_type'
                },
                {
                    data: 'date',
                    name: 'date'
                },
                {
                    data: 'payment_amount',
                    name: 'payment_amount'
                },
            ]
        });
    });

</script>
@endsection
