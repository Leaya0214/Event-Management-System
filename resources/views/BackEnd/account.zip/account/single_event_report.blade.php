@extends('BackEnd.master')

@section('content')

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                   <h4>Filter by Event</h4> 
                </div>
                <div class="card-body">
                    {{-- <form > --}}
                        {{-- <div class="form-group">
                            <label for="fromDate">From Date</label>
                            <input type="date" class="form-control" id="fromDate" name="fromDate">
                        </div>
                        <div class="form-group mt-3">
                            <label for="toDate">To Date</label>
                            <input type="date" class="form-control" id="toDate" name="toDate">
                        </div> --}}
                        @if($eventDetails)
                            <div class="form-group">
                                <label for="event" class="form-level">Select Event</label>
                                <select name="event" id="event" class="form-control">
                                    <option value=""selected disabled>Choose any event</option>
                                    @foreach($eventDetails as $event)
                                        <option value="{{$event->id}}">{{$event->venue}}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif
                        <button type="submit" class="btn btn-primary mt-3" onclick="viewEventHistory();">Filter</button>
                    {{-- </form> --}}
                </div>
            </div>
        </div>
        <div class="col-md-12 mt-5">
            <div class="card">
                <div class="card-header text-center">
                    {{-- <h3> Single Event Report</h3>
                    <h4 class="mt-3">Bridal Harmony</h4>
                    <h5 class="mt-3">For {{$monthname}} - {{$currentYear}}</h5> --}}
                </div>
                <div class="card-body">
                  
                    <div class="row">
                        <div class="col-md-12">
                            <div id="wrapper">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
<script>
    function viewEventHistory(){
        // $('#main_table').hide();
        $('.btn-warning').hide();
        var event_id = document.getElementById('event').value;
        var url = "{{route('single.report.history')}}"
        $.ajax({
            type:'GET',
            url:url,
            data:{event_id},
            success:function(data){
                $('#wrapper').html(data);
            }
        });
    }
</script>
@endsection