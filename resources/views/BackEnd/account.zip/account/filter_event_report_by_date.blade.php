<style>
    .table>tbody>tr>td,
    .table>tbody>tr>th,
    .table>tfoot>tr>td,
    .table>tfoot>tr>th,
    .table>thead>tr>td,
    .table>thead>tr>th {
        padding: 5px;
        line-height: 1.42857143;
        vertical-align: top;
        border-top: 0px solid #ddd;
        text-align: left !important;
        font-size: 15px;
    }
</style>


<div class="row">
    @php $date = date('d/m/Y'); @endphp
    <div class="col-md-12 text-end">
        <button class="mt-2 col-sm-1 btn btn-warning"
            onClick="document.title = 'Bridal Harmony-Event Report'; printDiv('printableArea'); "
            style="margin-right:100px"> <i class="fa fa-print"></i> Print </button>
    </div>
</div>

<div id="printableArea">
    <div class="row text-center">
        <div class="col-sm-12">
            <h2><strong> Bridal Harmony</strong></h2>
            <h3 style="margin-top:10px"><strong> Balance Sheet </strong></h3>
            <h6 style="margin-top:10px">{{ date('d/m/Y', strtotime($start_date)) }} -
                {{ date('d/m/Y', strtotime($end_date)) }}</h6>
        </div>
    </div>
    <div class="row" style="margin-top: 20px">
        <div class="col-sm-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Event Date</th>
                        <th>Event Venue</th>
                        <th>Event Price</th>
                        <th>Total Expense(Event Expense + Staff Payment + Fixed Expense Per Event)</th>
                        <th>Total Profit</th>
                    </tr>
                </thead>
                <tbody>
                    @php $total_profit = 0; @endphp
                    @foreach ($events as $v_event)
                        <tr>
                            <td>{{ $v_event->date }}</td>
                            <td>{{ $v_event->venue }}</td>
                            <td>{{ $v_event->package_price ? $v_event->package_price : $v_event->package->amount }}</td>
                            @php
                                $expense = App\Models\BackEnd\Expense::where('event_id', $v_event->id)->sum('amount');
                                $staff_payment = App\Models\BackEnd\EventwisePayment::where(
                                    'event_details_id',
                                    $v_event->id,
                                )->sum('payment_amount');
                                $total_expense = $expense + $staff_payment + $per_event_expense;
                                $total_profit = $v_event->package_price
                                    ? $v_event->package_price
                                    : $v_event->package->amount - $total_expense;
                            @endphp
                            <td>{{ $total_expense }}</td>
                            <td>{{ $total_profit }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</div>


<script>
    function printDiv(divId) {
        var printContents = document.getElementById(divId).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();
        document.body.innerHTML = originalContents;
    }
</script>
