@extends('BackEnd.master')
@section('css')
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
@endsection
@section('content')
<div class="col-md-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <div class="row  pr-3">
                <div class="col-md-6">
                    <h6 class="card-title">Staff Payment</h6>
                    <p class="text-muted mb-3"></p>
                </div>
            </div>
            <div class="table-responsive pt-3">
                <table class="table table-bordered table-hover user_table"
                style="width:100%; text-align:center;" data-table="true" id="stuffPaymentTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Staff Name</th>
                            <th>Total Event</th> 
                            <th>Total Payment</th>
                            <th>Total Advance</th>
                            <th>Total Due</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@foreach($payments as $payment)
    @php
        $paymentlogs = App\Models\BackEnd\StaffPaymentlog::where('user_id',$payment->user_id)->get();
    @endphp
<div class="modal fade bg-dark view_modal-{{ $payment->id }}" id=""
    tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Pyment Details</h5>
                <button type="button" class="close"
                data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                       <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="p-2" >Event Type</th>
                                <th class="p-2" >Event Date</th>
                                <th class="p-2" >Payment</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach( $paymentlogs  as $log)
                            <tr>
                                <th class="p-2">{{$log->event_details->type->type_name}}</th>
                                <th class="p-2">{{$log->event_details->date}}</th>
                                <th class="p-2">{{$log->payment_amount}}</th>
                            </tr>
                            @endforeach
                        </tbody>
                       </table>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-default"
                data-bs-dismiss="modal">close</button>
            </div>

        </div>
    </div>
</div>
@endforeach
@endsection

@section('js')
<script type="text/javascript">
    $(document).ready(function() {
        $('#stuffPaymentTable').DataTable({
       processing: true,
       serverSide: true,
       ajax: '{{route('staff.getAll')}}',
       columns: [{
               data: 'DT_RowIndex',
               name: 'DT_RowIndex',
               searchable: false,
               orderable: false
           },
           {
               data: 'staff',
               name: 'staff'
           },
           {
               data: 'total_event',
               name: 'total_event'
           },
           {
               data: 'total_payment',
               name: 'total_payment'
           },
           {
               data: 'total_advance',
               name: 'total_advance'
           },
           {
               data: 'total_due',
               name: 'total_due'
           },
           {
               data: 'action',
               name: 'action'
           },
       ]
   });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
    $(function () {
        $('.textarea').summernote({
            height:250
        })
    })
</script>
@endsection