<!DOCTYPE html>
<html lang="en-US">

<head>
    @include('FrontEnd.includes.meta&links')
</head>

<style>
    /* Default height for mobile */
    .responsive-image {
        height: 100px !important;
    }

    /* Media query for PC */
    @media screen and (min-width: 768px) {
        .responsive-image {
            height: 500px !important;
        }
    }
</style>


<body data-ng-app="siteApp" data-ng-cloak>
    @include('FrontEnd.includes.header')
    <div class="main-container">
        <section class="crew-header-section animatedParent animateOnce">
            <figure class="animated fadeInDownShort go">
                <img src="{{ asset('backend/content/' . $content->image) }}" alt="Bridal Harmony Cover Photo">
                <figcaption>{{ $content->title }}</figcaption>
            </figure>
        </section>

        <section class="crew-grid animatedParent animateOnce" style="margin-top: 17px;">
            @foreach($users as $user)
            <div class="crew-member animated fadeInUp go">
                <figure>
                    <span class="img-container"
                        style="background-image:url('{{asset('backend/user/'.$user->image)}}')">
                        <a href="{{ url('about/' . $user->id . '/' . $user->name )}}" class="know-more-link"
                            title="bridal harmony member">
                            <span>Know more &gt;</span>
                        </a>
                    </span>
                    <figcaption>
                        <h3><a href="">{{$user->name}}</a></h3>
                        <h4>{{$user->designation}}</h4>
                    </figcaption>
                </figure>
            </div>
            @endforeach
        </section>
    </div>


    @include('FrontEnd.includes.footer')

    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');
    </script>
    <!--GA code end-->


    <!-- Scripts -->

    <script>
        var APP = APP || {};
        APP.baseUrl = "https://www.theweddingfilmer.com/";
        APP.env = "production";
        window.Laravel = {
            "csrfToken": "pBMmAMmcYJIimuwoVWUjOs4sdDTYCNeOBmeQkYmx"
        };
        APP.isMobile = "";
        APP.isIpad = "";
        APP.isSafari = "";
        APP.isHome = "";
    </script>

    <script src="{{ asset('frontend') }}/js/vendor.js"></script>
    <script src="{{ asset('frontend') }}/js/site.js"></script>

</body>

</html>
