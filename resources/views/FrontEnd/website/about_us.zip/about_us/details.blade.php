<!DOCTYPE html>
<html lang="en-US">

<head>
    @include('FrontEnd.includes.meta&links')
</head>

<style>
    /* Default height for mobile */
    .responsive-image {
        height: 100px !important;
    }

    /* Media query for PC */
    @media screen and (min-width: 768px) {
        .responsive-image {
            height: 500px !important;
        }
    }
</style>


<body data-ng-app="siteApp" data-ng-cloak>
    @include('FrontEnd.includes.header')
    <div class="main-container">
        <section class="workshop-video-section animatedParent animateOnce">
            <div class="tutorial-wrapper ">
                <div class="tutorial-video animated fadeInLeftShort go">
                        <img src="{{asset('backend/user/'.$crew->image)}}" alt="The Wedding Filmer - Play icon">
                </div>
                <div class="workshop-content animated fadeInRightShort go">
                   
                        <div class="heading-wrapper">
                            <h3 class="workshop-heading">{{$crew->name}}</h3>
                            <div class="straight-border"></div>
                            <h3 style="font-size:20px">{{$crew->designation}}</h3>
                        </div>
                        <p class="workshop-description">{!! $crew->details !!}</p>
                        <div class="workshop-action">
                            <div class="price-container">
                                
                            </div>
                            <div class="take-class">
                                <a href="" class="class-action"></a>
                            </div>
                        </div>
                    
                </div>
            </div>
        </section>
    </div>


    @include('FrontEnd.includes.footer')

    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');
    </script>
    <!--GA code end-->


    <!-- Scripts -->

    <script>
        var APP = APP || {};
        APP.baseUrl = "https://www.theweddingfilmer.com/";
        APP.env = "production";
        window.Laravel = {
            "csrfToken": "pBMmAMmcYJIimuwoVWUjOs4sdDTYCNeOBmeQkYmx"
        };
        APP.isMobile = "";
        APP.isIpad = "";
        APP.isSafari = "";
        APP.isHome = "";
    </script>

    <script src="{{ asset('frontend') }}/js/vendor.js"></script>
    <script src="{{ asset('frontend') }}/js/site.js"></script>

</body>

</html>
