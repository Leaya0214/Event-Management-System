@extends('welcome')
@section('content')
<header class="master-header">
    <div>
        <a href="https://www.theweddingfilmer.com/"><img src="https://www.theweddingfilmer.com/images/twf_logo_small.png" class="mobile twf-mobile-logo clear" alt="Bridal Harmony - Logo"></a>

    </div>
    <div class="mobile-tab hide">
        <div id="nav-icon4">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
        <nav class="navbar">
            <ul class="desk-nav">
                <li>
                    <ul class="header-left">
                        <li><a href="https://www.theweddingfilmer.com/" class="nav ">Home</a></li>
                        <li><a href="https://www.theweddingfilmer.com/story" class="nav ">our story</a></li>
                        <li><a href="https://www.theweddingfilmer.com/work" class="nav active">our work</a></li>
                        <li><a href="https://www.theweddingfilmer.com/crew" class="nav ">our crew</a></li>
                    </ul>
                </li>
                <li class="logo-image"><a href="https://www.theweddingfilmer.com/" class="nav"><img class="twf-logo" src="https://www.theweddingfilmer.com/images/home/twf_logo_main.png" alt="Bridal Harmony - Logo"> </a></li>
                <li>
                    <ul class="header-right">
                        <li><a href="https://www.theweddingfilmer.com/blog" class="nav">blog</a></li>
                        <li><a href="https://www.theweddingfilmer.com/workshop" class="nav ">workshops</a></li>
                        <li><a href="https://www.theweddingfilmer.com/contact/create" class="nav ">contact</a></li>
                        <li><a href="https://www.theweddingfilmer.com/faqs" class="nav ">FAQ<small>s</small></a></li>
                    </ul>
                </li>
            </ul>
        </nav>
</header> 
    <div class="main-container">
        
        <section class="work-video-section animatedParent animateOnce">
            <div class="work-wrapper animated fadeIn " id="work-show">

                <div class="video-bg"
                    style="background-image: url({{ asset('backend/portfolio/' . $our_work_view->image) }});">
                </div>
                {{-- <a href="#" class="work-featured-video" data-url="https://player.vimeo.com/video/760342511?autoplay=1">
                    <img src="https://www.theweddingfilmer.com/images/home/play_icon.png" alt="play icon" class="">
                </a> --}}
            </div>
        </section>
        <div class="work-description-section animatedParent animateOnce" data-sequence="500">
           {!!$our_work_view->description!!}
        </div>
    </div>
@endsection
