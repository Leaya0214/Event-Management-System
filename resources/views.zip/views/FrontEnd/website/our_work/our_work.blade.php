<!DOCTYPE html>
<html lang="en-US">

<head>
   @include('FrontEnd.includes.meta&links')
</head>

<style>
    /* Default height for mobile */
    .responsive-image {
        height: 100px !important;
    }

    /* Media query for PC */
    @media screen and (min-width: 768px) {
        .responsive-image {
            height: 500px !important;
        }
    }
</style>


<body data-ng-app="siteApp" data-ng-cloak>
    @include('FrontEnd.includes.header')
    <div class="main-container">
        <section class="fetured-video-section">
            <div class="video-slider animatedParent animateOnce">
                @foreach($cinematographies as $c_data)
                <div class="video-cover animated fadeIn">
                    <div class="video-slider-content">
                        <img class="responsive-image" src="{{ asset('backend/portfolio/' . $c_data->image) }}"
                            alt="Bridal Harmony-cinematography">
                        <p class="video-caption">
                            {{$c_data->title}}
                        </p>
                        <div class="video-play-icon">
                            <a href="" class="work-show"
                                data-video-url="{{ getYoutubeEmbedUrl($c_data->video) }}" data-video-type="YouTube">
                                <img src="{{asset('frontend/images/play-icon.png')}}"
                                    alt="The Wedding Filmer - Play icon" class="work-video-play-icon">
                            </a>
                        </div>
                    </div>
                </div>
                @endforeach
                {{-- <div class="video-cover animated fadeIn">
                    <div class="video-slider-content">
                        <img src="/images/work/work_images/5AG8lAErQ2KPOZnyP9ECp8c9ClcNFU2Ts68p80xD.jpeg"
                            alt="The Wedding Filmer - Chal Le Chal">
                        <p class="video-caption">
                            Chal Le Chal | 2014
                        </p>
                        <div class="video-play-icon">
                            <a href="" class="work-show" data-id="182698848" data-video-type="Vimeo"
                                data-video-url="https://player.vimeo.com/video/182698848?autoplay=1">
                                <img src="https://www.theweddingfilmer.com/images/home/play_icon.png"
                                    alt="The Wedding Filmer - Play icon" class="work-video-play-icon">
                            </a>
                        </div>
                    </div>
                </div> --}}
            </div>
        </section>
        <section class="latest-work-section animatedParent animateOnce" style="width: 100%">
            <h2 class="heading animated fadeInDownShort">Photography</h2>
            
            <div class="work-list-latest  " id="most-popular-work">
                @foreach($photographies as $p_data)
                <div class="work-latest-parent  " data-id="1">
                    <div class="work"
                        style="background-image: url('{{ asset('backend/portfolio/' . $p_data->image) }}')">

                        <a href="">
                            <div class="work-description">
                                <h3> {{$p_data->title}} </h3>
                                <hr />
                                <p class="date"> 18 July 2022</p>
                                <p class="description" style="color:bisque">
                                    {!! $p_data->description !!}
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                @endforeach
                
                </div>
             
            </div>
        </section>
    <section class="latest-work-section animatedParent animateOnce">
            <h2 class="heading animated fadeInDownShort">Cinematography</h2>

            <div class="work-list-latest " id="latest-work">
                {{-- <div class="work-latest-parent  " data-id="1">
                    <div class="work"
                        style=" background-image: url(/images/work/work_thumbnail_images/cUqbliqpLjNcalBTciitrTMKeXYer1HfmmKR94qi.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/100/kiara-sidharth-ranjha-the-wedding-filmer">
                            <div class="work-description">
                                <h3> Kiara &amp; Sidharth </h3>
                                <hr />
                                <p class="date">07 February 2023</p>
                                <p class="description">
                                    Very few humans are so generous with their love that they are willing to share it
                                    with the world. She wanted to walk towards Sidharth on &lsquo;Ranjha&rsquo;, which
                                    is their song. &ldquo;But it&rsquo;s a sad song!&rdquo; I argued. &ldquo;But
                                    it&rsquo;s our song!&rdquo; She maintained! So we rewrote the lyrics with respect to
                                    fit the situation we were in, and suddenly, everyone&rsquo;s dreams came true!
                                    #twfclassics #theweddingfilmer #twfmusic
                                    Videography team - Vishal Punjabi, Abhijit Datta, Vishnu Tenkayala, Raj Sampad,
                                    Farhan Ahmed, Rahul Gulabani, Simran Thakur
                                    Line producer - Siddhi Kanakia
                                    Edited by - Jenish Maru
                                    Photography - House On The Clouds
                                    Venue - Suryagarh
                                    Music Credits: Sarangi - Mudassir Khan
                                    Vocalists - Prerna Arora, Ashwani Basoya
                                    Composed &amp; Arranged by - Kingshuk Chakravarty, Mayank Choudhary
                                    Special thanks to: Karan Johar and Manish Malhotra
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div> --}}
                @foreach($cinematographies as $cine)
                <div class="work-latest-parent  " data-id="1">
                    <div class="work"
                        style=" background-image: url('{{ asset('backend/portfolio/' . $cine->image) }}')">

                        <a
                            href="">
                            <div class="work-description">
                                <h3>{{$cine->title}}</h3>
                                <hr />
                                <p class="date">12 January 2023</p>
                                <p class="description">
                                   {!! $cine->description !!}
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                @endforeach
            </div>
        </section> 
        {{-- <section class="latest-work-section animatedParent animateOnce">
            <h2 class="heading animated fadeInDownShort">our favourites</h2>

            <div class="work-list-latest  " id="favourite-work"
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/zYyTERdNKLNCY6Jr3UezWMBavkwUhJ3aJnSjLBla.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/93/arpita-kunal-the-wedding-filmer">
                            <div class="work-description">
                                <h3> Arpita &amp; Kunal </h3>
                                <hr />
                                <p class="date"> 28 August 2022 </p>
                                <p class="description ">
                                    When two of our favourite designers finally get married, it&rsquo;s bound to be
                                    ethereal. Kunal looked like a modern day Nawab, and Arpita was so happy to be
                                    married, she couldn&rsquo;t help sway to her mandap. Now you know why I was jumping
                                    and hopping to capture her enter!Featuring our latest wedding song, Jaane Nahin Do
                                    (Never Let Me Go), inspired by Elvis&rsquo;s Love Me Tender, sung
                                    by&nbsp;@devangichopra&nbsp;and composed by&nbsp;@sanjeevwadhwani&nbsp;&amp; written
                                    by&nbsp;@shraddhasehgalmusic&nbsp;exclusively for The Wedding Filmer!When love is
                                    fulfilled like this after a decade and a half, joy is inevitable.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/l3kWlGLuOGpIG7RGjNQSsudgo4fdrzcXSGi5OTQu.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/94/arpita-kunal-jindd-maahi-the-wedding-filmer">
                            <div class="work-description">
                                <h3> Arpita &amp; Kunal </h3>
                                <hr />
                                <p class="date"> 28 August 2022 </p>
                                <p class="description ">
                                    When love is fulfilled after a decade and half, joy like this is inevitable. Music
                                    is the soul of the films we make and I couldn&rsquo;t think of a better track to
                                    celebrate Kunal &amp; Arpita&rsquo;s wedding. Presenting our latest song, Jind Mahi,
                                    with The Wedding Filmer Touch. Wait till the end and see my Grooms lift my
                                    groom!Music CreditsLabel: The Wedding FilmerComposed by : Kingshuk ChakravartyLyrics
                                    : ShelleeMusic Production : Mayank Chaudhary, Vishal PunjabiMale Vocals : Kingshuk
                                    Chakravarty, Jaspreet JaszFemale Vocals : Roshni SahaMix &amp; Mastered by : Gaurav
                                    Chopra
                                    Filmed by : Raj Sampad, Kashinath Sangare, Simran Thakur, Jenish Maru &amp; Farhan
                                    Ahmed, assisted by Piyush Ghai
                                    Edited by :&nbsp;Jenish Maru
                                    Sound &amp; Color : Vishnu Bhat &amp; Kedar Patil
                                    Shot on :&nbsp;Sony Alpha
                                    #AMKRforever&nbsp;#twfmusic&nbsp;#twfclassics&nbsp;#fairytales
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/TAJQpajbOJmCMlgm4WbqCInHYz0vU31tQJX7mKoA.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/89/yeh-aashiqui-patralekhaa-rajkummar">
                            <div class="work-description">
                                <h3> Yeh Aashiqui | Patralekhaa &amp; Rajkumaar </h3>
                                <hr />
                                <p class="date"> 01 December 2021 </p>
                                <p class="description ">
                                    In eleven years of filming weddings, I haven&#039;t been&nbsp;prouder of my team!
                                    When Devika Narain contacted&nbsp;me to film this wedding, it was pretty late in the
                                    day&nbsp;and the truth was we have been stretched thin with&nbsp;weddings piling up
                                    due to the pandemic. She&nbsp;arranged a meeting in his home and upon
                                    meeting&nbsp;them, I instantly knew this would be special.&nbsp;The fear of not
                                    being able to do justice was very&nbsp;present in my heart but Neha Sharma, Kunal
                                    Singh&nbsp;Abhijeet Datta and Rajit Kalra assured they had my&nbsp;back, and after
                                    filming the first day, I left for Paris for&nbsp;another shoot. The following days,
                                    they shot with&nbsp;respect, love and a lot of laughter, Vijay Sehgal&nbsp;arranged
                                    for the edit to happen exactly how it should&nbsp;and Sagar Desai worked his magic
                                    with a song&nbsp;penned by Shraddha Sehgal just for us.&nbsp;Their love story stood
                                    the test of time and inspired&nbsp;this song. This is how wedding films are made in
                                    our&nbsp;studio. Proof that it&#039;s not one man that makes a film,but a group of
                                    people who want only good things for&nbsp;the world around them.
                                    &nbsp;
                                    Music Credits:
                                    Female vocals by Devangi Chopra &amp; Sharmistha ChatterjeeMale vocals by Vivek
                                    Hariharan &amp; Raghav MeattleBackground vocals and Mixed &amp; Mastered by Gaurav
                                    ChopraLabel - The Wedding Filmer
                                    Wedding Credits:
                                    Delightful decor by DevikanarainandcompanyPhaadu photos by Joseph RadhikPerfect
                                    planning by A new knotShot on Sony Alpha
                                    #twfclassics #twfmusic#theweddingfilmer #yehaashiqui #rajpatra
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/MfCZlQLAtX0fhXejCUhCr8SRPpGaKcfQyt1hZhKJ.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/88/i-wont-give-up">
                            <div class="work-description">
                                <h3> I Won&#039;t Give Up | Dharshinee &amp; Vishal | The wedding Filmer </h3>
                                <hr />
                                <p class="date"> 06 July 2021 </p>
                                <p class="description ">
                                    Dharshinee and Vishal&#039;s wedding was one of the first few we filmed after the
                                    long lockdown last year. Dharshinee got in touch with us well before COVID was a
                                    real concern. Yet as the world was thrown into uncertainty, Dharshinee was certain
                                    she would get married on her chosen day and have us there to film it.
                                    When I finally met her in person: sweet, gentle and wise beyond her years I realised
                                    that it was with the same spirit that Vishal and she had navigated the ups and downs
                                    in their relationship- keeping an eye on what they wanted and never giving up.
                                    And it paid off- they got married in November, with the blessings of all their loved
                                    ones and luckily for us, with us filming it! So, what did I learn from this
                                    experience? Exactly the same lesson that Dharshinee learnt from her love
                                    story&hellip;
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/vxHgEVLXWrXrNqwFCxXgMBLhXLOvikU17obWVLtk.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/75/peer-vi-tu-out-now">
                            <div class="work-description">
                                <h3> Peer Vi Tu </h3>
                                <hr />
                                <p class="date"> 16 December 2020 </p>
                                <p class="description ">
                                    For all of you who have patiently waited, ask and you shall receive (eventually!) -
                                    Peer Vi Tu the full track
                                    &nbsp;
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/EfWNBxZN9QygmjE3APXGpBsgr9e2Z4ybHRtpyvNM.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/59/the-color-of-life-kiran-sumir">
                            <div class="work-description">
                                <h3> Kiran &amp; Sumir </h3>
                                <hr />
                                <p class="date"> 02 March 2020 </p>
                                <p class="description ">
                                    Five years later, your story still brings us a lot of joy Kiran &amp; Sumir. We
                                    can&rsquo;t wait for your little one, Safina to admire her parents&rsquo; love just
                                    as much as we do! Love looks like this wedding. Love sounds like this song and when
                                    every heart is so beautiful, it&#039;s hard to go wrong. The Color Of Life,
                                    featuring a cover of &lsquo;Dust to Dust&rsquo; by The Civil Wars performed by
                                    Devangi Chopra.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/fru7494iGGhSWtwMJ3acEuJbdcLjYlLhICdZQOaA.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/49/a-love-like-this-hanna-saif">
                            <div class="work-description">
                                <h3> Hanna &amp; Saif </h3>
                                <hr />
                                <p class="date"> 06 October 2019 </p>
                                <p class="description ">
                                    Unlike most love stories we hear, Hanna &amp; Saif didn&rsquo;t have it easy from
                                    the start. Cultural differences and adversities were constantly put in their way,
                                    only to see if what they wanted was worth fighting for. She said to me,
                                    &ldquo;Obstacles do not block our paths Vishal. They are the path. Overcoming them
                                    is what makes like meaningful!&rdquo; And just like the river they got married in
                                    front of, their love went on and on to reach this day.
                                    &nbsp;
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/w3yrB9hPXcP6MzVZRJMPRyMrUiolgH58VktAaRlQ.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/33/meher-sameer">
                            <div class="work-description">
                                <h3> Meher &amp; Sameer </h3>
                                <hr />
                                <p class="date"> 12 June 2018 </p>
                                <p class="description ">
                                    Meher grew up waiting to find her soulmate. But little did she know that he was
                                    sitting in the next classroom the whole time.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/i8Q56eszZZAXhB9qfwwTashopcJvHljfTEJL5yBX.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/11/gayabh">
                            <div class="work-description">
                                <h3> Gayatri &amp; Vallabh </h3>
                                <hr />
                                <p class="date"> 13 July 2017 </p>
                                <p class="description ">
                                    Love gave birth to marriage, and marriage laid the cornerstone for family. Whether
                                    it&rsquo;s the family you start out with, the one you end up with or the one you
                                    gain along the way.
                                    Watch four love stories in Gayatri &amp; Vallabh&rsquo;s wedding trailer set against
                                    the breathtaking landscape of Montreux, Switzerland.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent " data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/X8IiKxOV1NE7by8MZICppewoFz9jB44szL3YGM7c.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/13/divine-intervention">
                            <div class="work-description">
                                <h3> Kirtana &amp; Karan </h3>
                                <hr />
                                <p class="date"> 10 July 2015 </p>
                                <p class="description ">
                                    A touch of madness, a whole lot of love and an unwavering faith in the Almighty,
                                    Divine Intervention is a film that would have the staunchest non believers
                                    wondering. &#039;what is love if not a sign from God?
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="latest-work-section animatedParent animateOnce" style="width: 100%">
            <h2 class="heading animated fadeInDownShort">Behind The Scenes</h2>
            <div class="work-list-latest" id="behind-the-scene">
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/NbOQVu3FHWsrHvaeQQEDR85vFMZVD5M2edkBrZXd.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/64/khushnaseeb-hun-bts-vipasha-cj">
                            <div class="work-description">
                                <h3> Vipasha &amp; CJ </h3>
                                <hr />
                                <p class="date"> 01 April 2020</p>
                                <p class="description">
                                    Be grateful for everything that comes with love because when you wear a heart of
                                    gratitude, you always feel blessed!
                                    Vipasha and Kim truly are each other&rsquo;s blessings! ❤️
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/yOLRvarPUEtzz2JKQqLDFkK5l3m4MFk5EIJ4NLVJ.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/34/kareebi-teri-behind-the-song">
                            <div class="work-description">
                                <h3> Kareebi Teri - Behind The Song </h3>
                                <hr />
                                <p class="date"> 08 August 2018</p>
                                <p class="description">
                                    Ideas are not born out of a mystic void. They are little breezes of inspiration that
                                    we catch from the people and the places around us. With Riccha &amp; Andrew, it was
                                    watching them perform at the Sangeet which inspired all of us to make this song,
                                    including them.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/sMo5ZpnBJRy0vRXXDe2hTGpx1wG7SzDy2JYiOGkj.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/35/meher-teri-behind-the-song">
                            <div class="work-description">
                                <h3> Meher Teri - Behind The Song </h3>
                                <hr />
                                <p class="date"> 27 July 2017</p>
                                <p class="description">
                                    To create a song that resonates with the story being told on screen has been our
                                    attempt with Meher Teri, a TWF cover of Mumford &amp; Sons&rsquo; I Will Wait for
                                    Inder &amp; Simran&rsquo;s film. Watch the making below to see what went behind
                                    creating this soulful rendition.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/wxWV4GRxS9bJvm4sJX8mIwudtDOLnRJi2YoX4q6i.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/36/chal-le-chal-the-making">
                            <div class="work-description">
                                <h3> TWF x Devangi Chopra </h3>
                                <hr />
                                <p class="date"> 14 July 2015</p>
                                <p class="description">
                                    A fantastic bunch of musicians, film makers and generally good people are quietly
                                    coming together to change the music scene at Indian weddings! See who they are!
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/x1cTuWzwWBzXUhYsRvZHIkSUyzxVvZZwYNQopmRm.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/38/ishqedaariyan-the-story-behind-the-song">
                            <div class="work-description">
                                <h3> TWF x The Music Factory </h3>
                                <hr />
                                <p class="date"> 09 September 2018</p>
                                <p class="description">
                                    Each song is made with just as much thought and attention as each film at The
                                    Wedding Filmer. This song talks about love and friendship and all that makes it
                                    one.&nbsp;
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/5waAgmGxi4unnQdkGcQ3KeUN3ho879mGgIaLX0TC.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/40/chammak-challo-the-making-of-the-song">
                            <div class="work-description">
                                <h3> Bollywood Diaries ft. Akon </h3>
                                <hr />
                                <p class="date"> 27 October 2011</p>
                                <p class="description">
                                    A very small documentary that delves into the life of Bollywood and it&#039;s
                                    creative processes in studios, living rooms and offices of various production
                                    houses.
                                    Captured &amp; Directed by - Vishal Punjabi
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="work-latest-parent" data-id="1">
                    <div class="work"
                        style="background-image: url(/images/work/work_thumbnail_images/GUrHkOKdZweZ8NBXuQbMrjdo1cBFBRYyFO4a7NYI.jpeg)">

                        <a href="https://www.theweddingfilmer.com/work/45/our-first-ever-telugu-song">
                            <div class="work-description">
                                <h3> Bandhamey - Behind The Scenes </h3>
                                <hr />
                                <p class="date"> 17 April 2019</p>
                                <p class="description">
                                    The Wedding Filmer brings an original song that celebrates taking a leap of faith
                                    and falling in love mysteriously and yet completely.
                                </p>
                                <span class="view-btn">VIEW</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>  --}}
    </div>


    @include('FrontEnd.includes.footer')
   
    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');
    </script>
    <!--GA code end-->


    <!-- Scripts -->

    <script>
        var APP = APP || {};
        APP.baseUrl = "https://www.theweddingfilmer.com/";
        APP.env = "production";
        window.Laravel = {
            "csrfToken": "pBMmAMmcYJIimuwoVWUjOs4sdDTYCNeOBmeQkYmx"
        };
        APP.isMobile = "";
        APP.isIpad = "";
        APP.isSafari = "";
        APP.isHome = "";
    </script>

<script src="{{asset('frontend')}}/js/vendor.js"></script>
<script src="{{asset('frontend')}}/js/site.js"></script>

</body>

</html>
