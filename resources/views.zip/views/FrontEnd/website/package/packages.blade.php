<!DOCTYPE html>
<html lang="en-US">

<head>
    @include('Frontend.includes.meta&links')
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .modal-body ul li {
            line-height: 23px;
        }
    </style>
</head>

<body data-ng-app="siteApp" data-ng-cloak>
    @include('Frontend.includes.header')
    <div class="main-container">
        <section class="latest-work-section animatedParent animateOnce" style="width: 100%">
            <!--yyyyy-->
            <div class="container">
                <div class="row">
                    <div class="col-md-12" style="text-align:center">
                        <h2 class="heading animated fadeInDownShort">Packages</h2>
                    </div>
                    <div class="col-md-12" style="text-align:center">
                        <div class="col-md-2" style="text-align:center">&nbsp;</div>
                        <div class="col-md-7" style="float:left;text-align:center">
                            <ul class="nav up-content nav-tabs alt-font text-uppercase alt-font text-small display-inherit text-center font-weight-500"
                                style="width:100%; float:left;text-align:center;">
                                @foreach ($package_type as $type)
                                    <li class=""><a data-toggle="tab"
                                            href="#{{ $type->package_type_name }}">{{ $type->package_type_name }}</a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="tab-content">
                    <div id="home" class="tab-pane fade in active">


                        <div class="container">
                            <div class="row" style="background-color:#EFEFEF; margin-bottom:20px;">
                                <div class="col-12" style="text-align:center">&nbsp;</div>

                                <div class="col-md-3" style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        INFINITE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        6 Photographers<br>
                                        JAWAD/FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any TWO will Lead <br>


                                        4 Cinematographers<br>
                                        STORYTELLING VIDEO <br>
                                        Prints: 200 - 5L<br>
                                        ALBUM<br>
                                        PHOTOBOOK<br>
                                        Duration: Venue + Before & After (7 HOURS)<br>

                                        *Recommended for Long Holud& Wedding*<br>



                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 2,50,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModal">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModal">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h3 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        INFINITE</h3>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">


                                                                <ul style="list-style:square">
                                                                    <li>6 Photographers (2 Lead & 4 Associates)</li>
                                                                    <li>JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT /
                                                                        JISAN will Lead<br><strong>(Any 2 will
                                                                            Lead)</strong></li>

                                                                    <li>Duration: Venue + Before & After (7 HOURS)</li>
                                                                    <li>Prints - 200 Units - 5L, 2 Units - 12L</li>
                                                                    <li>Album with Custom Cover - 2 Units</li>
                                                                    <li>Photobook - 10 Inch x 10 Inch - 1 Unit</li>
                                                                    <li>Makeover/Pre Shoot on the Event Day</li>
                                                                    <li>Bashor Shoot (If Required)</li>
                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>2 Senior & 2 Associate Cinematographers</li>
                                                                    <li>Makeover/Pre Shoot& Bashor Video Shoot</li>
                                                                    <li>A short STORY TELLING 3-7 min TRAILER will be
                                                                        done highlighting the entire event& 20-40 Mins
                                                                        Long Video.</li>

                                                                </ul>

                                                            </div>

                                                        </div>


                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold;  font-family:ProximaNova-Regular;">
                                                        TK. 2,50,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>
                                <div class="col-md-3" style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SIGNATURE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">

                                        4 Photographers<br>
                                        JAWAD /FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead<br>
                                        3 Cinematographers<br>
                                        STORYTELLING VIDEO<br>
                                        Prints: 100 5L<br>
                                        ALBUM<br>
                                        PHOTOBOOK<br>
                                        Duration: Venue + Before(5 Hours)<br><br>



                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 1,70,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModal1">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModal1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        SIGNATURE</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>4 Photographers (1 Lead & 3 Associates)</li>
                                                                    <li>JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT /
                                                                        JISAN will Lead <strong>(Any 1 will
                                                                            Lead)</strong></li>
                                                                    <li>Prints - 100 Units - 5L, 2 Units - 12L</li>
                                                                    <li>Album with Custom Cover - 1 Unit</li>
                                                                    <li>Photobook - 12 Inch x 8 Inch - 1 Unit</li>
                                                                    <li>Duration: Venue + Before(5 Hours)
                                                                        <br>(Same Day Pre Shoot at Makeup Artist /
                                                                        Nearby Location)
                                                                    </li>
                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>1 Senior & 2 Associate Cinematographers.</li>
                                                                    <li>A short STORY TELLING 3-7 min TRAILER will be
                                                                        done highlighting the entire event & 20-40 Mins
                                                                        Long Video.
                                                                        <br><strong>*Recommended for Long Holud&
                                                                            Wedding*.</strong>
                                                                    </li>
                                                                </ul>

                                                            </div>

                                                        </div>


                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold;  font-family:ProximaNova-Regular;">
                                                        Tk- 1,70,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SAPPHIRE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">

                                        3 Photographers<br>
                                        JAWADCHOWDHURY (For 2 Hours) will Lead <br>
                                        2 Cinematographers<br>
                                        (3 Mins Trailer & Long Video)<br>
                                        Prints: 100 Units - 4R<br>
                                        Duration: Venue (5 hours)<br>

                                        <strong>*Recommended for Mid-size Events*</strong><br><br><br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 1,20,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModal2">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModal2">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        SAPPHIRE</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>3 Photographers (1 Lead & 2 Associates)</li>
                                                                    <li>JAWAD CHOWDHURY will Lead(2 Hours) </li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: 5 Hours (Venue) </li>

                                                                </ul>
                                                            </div>





                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px; font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">

                                                                    <li>1 Senior & 1 Associate Cinematographers. </li>
                                                                    <li>A short 3 min TRAILER will be done highlighting
                                                                        the entire event& 20-40 Mins Long Video. </li>


                                                                </ul>


                                                            </div>



                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 1,20,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row" style="background-color:#EFEFEF; margin-bottom:20px;">
                                <div class="col-12" style="text-align:center">&nbsp;</div>

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        PLATINUM</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">



                                        3 Photographers<br>
                                        FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead <br>
                                        2 Cinematographers<br>
                                        Prints: 100 Units - 4R <br>
                                        Duration: 5 Hours (Venue Only)<br><br><br><br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 80,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModals1">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModals1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        PLATINUM</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">

                                                                    <li>3 Photographers (1 Lead & 2 Associates) </li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) </li>

                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">
                                                                <ul style="list-style:square">
                                                                    <li>2 Associate Cinematographers</li>
                                                                    <li>A short 3 min TRAILER will be done highlighting
                                                                        the entire event& 20-40 Mins Long Video.<br>
                                                                        <strong>*Recommended for Mid
                                                                            SizeHolud/Wedding/Reception*</strong>
                                                                    </li>

                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 80,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->

                                </div>
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        GOLD</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        2 Photographers<br>
                                        FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead<br>
                                        2 Cinematographer<br>
                                        Prints: 100<br>
                                        Duration: Venue <br>

                                        <strong>*Recommended for Mid SizeHolud/Wedding/Reception*</strong><br><br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 65,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModals2">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModals2">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        GOLD</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>2 Photographers (1 Lead & 1 Associate) </li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) </li>

                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">


                                                                <ul style="list-style:square">

                                                                    <li>2 Associate Cinematographers</li>
                                                                    <li>A short 3 min TRAILER will be done highlighting
                                                                        the entire event& 20-40 Mins Long Video.<br>
                                                                        <strong>*Recommended for Mid
                                                                            SizeHolud/Wedding/Reception*</strong>
                                                                    </li>

                                                                </ul>


                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 65,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>

                                <!--New Package-->


                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SILVER</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        2 Photographers (1 Lead & 1 Associate)<br>
                                        1 Associate Cinematographer<br>
                                        Prints - 100 Units - 4R<br>

                                        Duration: Venue (5 Hours)<br>
                                        <strong>* Recommended for Small/Intimate event *</strong><br>
                                        <br><br><br><br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 55,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModals2nm">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModals2nm">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        SILVER</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>2 Photographers (1 Lead & 1 Associate) </li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours)</li>

                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">


                                                                <ul style="list-style:square">

                                                                    <li>1 Associate Cinematographer</li>
                                                                    <li>A short 2-3 mins Highlight video & Long
                                                                        video<br>
                                                                        <strong>*Recommended for Small/Intimate
                                                                            events*</strong>
                                                                    </li>

                                                                </ul>


                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 55,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>
                                <!--New Package-->

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        BASIC</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        1 Photographer<br>
                                        1 Cinematographer<br>
                                        Prints: 100 <br>
                                        Duration: Venue (5 HOURS)<br><br><br><br><br><br><br>






                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 35,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModals2mn">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModals2mn">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        BASIC</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                PHOTOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>1 Photographer</li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) </li>
                                                                </ul>

                                                            </div>

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; font-weight:bold; padding-bottom:5px;font-family:Nexa_Black;">
                                                                CINEMATOGRAPHY</div>
                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">


                                                                <ul style="list-style:square">

                                                                    <li>1 Associate Cinematographers</li>
                                                                    <li>A short 3 min TRAILER will be done highlighting
                                                                        the entire event& 20-40 Mins Long Video.<br>
                                                                        <strong>*Recommended for Intimate / Homely
                                                                            events*</strong>
                                                                    </li>


                                                                </ul>


                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 35,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>

                            </div>

                        </div>
                    </div>
                    <div id="menu1" class="tab-pane fade">
                        <!--Second Part-->

                        <div class="container">
                            <div class="row" style="background-color:#EFEFEF; margin-bottom:20px;">
                                <div class="col-12" style="text-align:center">&nbsp;</div>


                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        INFINITE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">

                                        JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any TWO will Lead<br>
                                        Prints: 200 - 5L<br>
                                        ALBUM<br>
                                        PHOTOBOOK<br>
                                        Duration: Venue + Before & After (7 HOURS)<br>

                                        <strong>*Recommended for Long Holud& Wedding*</strong>



                                        <br><br>
                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 180,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalpj2">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalpj2">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        INFINITE</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>4 Photographers (1 Lead & 3 Associates)</li>
                                                                    <li>JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT /
                                                                        JISAN will Lead(Any 1 will Lead) </li>
                                                                    <li>Prints - 100 Units - 5L, 2 Units - 12L</li>
                                                                    <li>Album with Custom Cover - 1 Unit</li>
                                                                    <li>Photobook - 12 Inch x 8 Inch - 1 Unit</li>
                                                                    <li>Duration: Venue + Before(5 Hours) </li>
                                                                    <li> (Pre Shoot at Makeup Artist / Nearby Location)
                                                                    </li>

                                                                </ul>

                                                            </div>



                                                        </div>


                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold;  font-family:ProximaNova-Regular;">
                                                        TK. 180,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SIGNATURE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        4 Photographers<br>
                                        JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead<br>
                                        Prints: 100 5L<br>
                                        ALBUM<br>
                                        PHOTOBOOK<br>
                                        Duration: Venue + Before(5 Hours)<br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 1,10,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalpj3">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalpj3">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        SIGNATURE</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>4 Photographers (1 Lead & 3 Associates)</li>
                                                                    <li>JAWAD / FARHAN / TANZIM / SHUVO / SHOIKOT /
                                                                        JISAN will Lead(Any 1 will Lead) </li>
                                                                    <li>Prints - 100 Units - 5L, 2 Units - 12L</li>
                                                                    <li>Album with Custom Cover - 1 Unit</li>
                                                                    <li>Photobook - 12 Inch x 8 Inch - 1 Unit</li>
                                                                    <li>Duration: Venue + Before(5 Hours) </li>
                                                                    <li> (Pre Shoot at Makeup Artist / Nearby Location)
                                                                    </li>



                                                                </ul>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 1,10,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SAPPHIRE</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">

                                        3 Photographers<br>
                                        JAWAD (For 2 Hours) will Lead <br>
                                        Prints: 100 Units - 4R<br>
                                        Duration: Venue (5 Hours)<br>

                                        <strong>*Recommended for Mid-size Events*</strong><br><br><br><br>



                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 70,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalpj3vbnm">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalpj3vbnm">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        SAPPHIRE</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>3 Photographers (1 Lead & 2 Associates)</li>
                                                                    <li>JAWAD CHOWDHURY will Lead(2 Hours) </li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) </li>


                                                                </ul>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 70,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>



                            </div>

                        </div>

                        <div class="container">
                            <div class="row" style="background-color:#EFEFEF; margin-bottom:20px;">
                                <div class="col-12" style="text-align:center">&nbsp;</div>

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        PLATINUM</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">

                                        3 Photographers<br>
                                        FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead<br>

                                        Prints: 100 Units - 4R <br>
                                        Duration: 5 Hours (Venue Only)<br><br><br>



                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 50,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalpj4">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalpj4">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        PLATINUM</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>3 Photographers (1 Lead & 2 Associates) </li>
                                                                    <li>FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any
                                                                        ONE will Lead</li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) <br>


                                                                        <strong>*Recommended for Mid
                                                                            SizeHolud/Wedding/Reception*</strong>
                                                                    </li>


                                                                </ul>
                                                            </div>


                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 50,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->


                                </div>

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        GOLD</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any ONE will Lead<br>
                                        Prints: 100 <br>
                                        Duration: Venue <br>

                                        *Recommended for Mid SizeHolud/Wedding/Reception*<br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 40,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalpj5">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalpj5">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        GOLD</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>2 Photographers (1 Lead & 1 Associate) </li>
                                                                    <li>FARHAN / TANZIM / SHUVO / SHOIKOT / JISAN any
                                                                        ONE will Lead</li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours) </li>
                                                                    <br><strong>*Recommended for Mid
                                                                        SizeHolud/Wedding/Reception*</strong></li>


                                                                </ul>
                                                            </div>


                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 40,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->


                                </div>

                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        BASIC</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">


                                        1 Photographer<br>
                                        Prints: 100 <br>
                                        Duration: Venue (5 HOURS)<br><br><br><br><br>




                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; border-bottom:1px solid #CCCCCC; font-weight:bold; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 20,000 / Day</div>

                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:14px; margin-top:20px;padding-bottom:20px; font-family:ProximaNova-Regular;">
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#myModalsf2">Details</button></div>


                                    <!-- Modal -->
                                    <div class="modal" id="myModalsf2">
                                        <div class="modal-dialog">
                                            <div class="modal-content">

                                                <!-- Modal Header -->
                                                <div class="modal-header">
                                                    <h4 class="modal-title"
                                                        style="width:90%; float:left; text-align:center;font-family:Nexa_Black;">
                                                        BASIC</h4>
                                                    <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                </div>

                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                    <div style="width:100%; float:left;">
                                                        <div style="width:3%; float:left;">&nbsp;</div>
                                                        <div style="width:97%; float:left;">

                                                            <div
                                                                style="width:100%; float:left; font-size:14px; padding-bottom:5px; font-weight:500; font-family:ProximaNova-Regular;">

                                                                <ul style="list-style:square">
                                                                    <li>1 Photographer</li>
                                                                    <li>Prints - 100 Units - 4R</li>
                                                                    <li>Duration: Venue (5 Hours)

                                                                        <br><strong>*Recommended for Intimate / Homely
                                                                            events*</strong>
                                                                    </li>

                                                                </ul>

                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div
                                                        style="width:100%; float:left; text-align:center; font-size:14px; font-weight:bold; font-family:ProximaNova-Regular;">
                                                        TK. 20,000 / Day</div>
                                                </div>

                                                <!-- Modal footer -->
                                                <div class="modal-footer">
                                                    <form action="https://snapshotbd.com/index.php/home/contact">
                                                        <button type="submit" class="btn btn-primary"
                                                            style="font-family:ProximaNova-Regular;">Contact</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                </div>







                            </div>

                        </div>






                        <!--Second Part-->
                    </div>
                    <div id="menu3" class="tab-pane fade">

                        <!--Forth Part-->

                        <div class="container">
                            <div class="row" style="background-color:#EFEFEF; margin-bottom:20px;">
                                <div class="col-12" style="text-align:center">&nbsp;</div>
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        DRONE </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="115" src="https://snapshotbd.com/assets/images/drone.png" />
                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        Drone flying time 1 hour</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 24,999<br><br></div>

                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        4K VIDEO</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="100" src="https://snapshotbd.com/assets/images/4k-logo.png" />
                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        Upgrade <strong>HD to 4K</strong><br>Video Camera each</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 9,999</div>

                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SLOW MOTION VIDEO</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="65"
                                            src="https://snapshotbd.com/assets/images/slow-motion.png" /></div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        Upgrade to Slow motion video<br>Full Event</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        29,999</div>


                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        JIMMY JIB</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="112"
                                            src="https://snapshotbd.com/assets/images/jimmy-jib.png" /></div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        &nbsp;</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 29,999</div>


                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        LED DISPLAY with LIVE CAM</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="100" src="https://snapshotbd.com/assets/images/led.png" />
                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        6 x 8 feet – TK- 16,000<br>8 x 12 feet – TK- 24,000<br>10 x 20 feet – TK- 35,000
                                    </div>


                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        PROJECTOR SERVICES</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="120"
                                            src="https://snapshotbd.com/assets/images/Projector.png" /></div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        Back Projector 10 x 8 feet – TK- 9,999<br>Back Projector 12 x 16 feet TK-
                                        11,999<br>Front Projector 6 x 4 feet TK- 5,999<br>FULL HD Live Cam –TK- 3,999
                                    </div>


                                </div>
                                <!--Box-End-->
                                <!--Box-Start-->
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SIGNATURE PHOTOBOOK</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="100"
                                            src="https://snapshotbd.com/assets/images/photobook.png" /></div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        Photobook containing 10 Leaves<br>Dimension- 10 x 10 inch<br>Exclusively
                                        Designed by JAWAD CHOWDHURY</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 19,999</div>


                                </div>
                                <div class="col-md-3"
                                    style="background-color:#F4F4F4; height:268px; box-shadow: 0 0 10px 0px #999;">
                                    <div class="col-12"
                                        style="text-align:center; font-weight:bold; font-size:19px; margin-top:20px;font-family:Nexa_Black;">
                                        SIGNATURE PHOTO ALBUM </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:5px; padding-bottom:5px;font-family:ProximaNova-Regular;">
                                        <img width="150" src="https://snapshotbd.com/assets/images/Album.png" />
                                    </div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:14px; padding-top:35px; padding-bottom:17px;font-family:ProximaNova-Regular;">
                                        Exclusive Photo Album<br>All Printed Photos will be Pasted Inside</div>
                                    <div class="col-12"
                                        style="text-align:center; font-size:16px; padding-bottom:20px; font-weight:bold; font-family:ProximaNova-Regular;">
                                        TK. 4,999</div>


                                </div>
                            </div>
                        </div>
                        <!--Forth Part-->


                    </div>
                </div>
            </div>
            <!--yyyyy-->
        </section>
    </div>

    @include('Frontend.includes.footer')
    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');
    </script>
    <!--GA code end-->


    <!-- Scripts -->

    <script>
        var APP = APP || {};
        APP.baseUrl = "https://www.theweddingfilmer.com/";
        APP.env = "production";
        window.Laravel = {
            "csrfToken": "pBMmAMmcYJIimuwoVWUjOs4sdDTYCNeOBmeQkYmx"
        };
        APP.isMobile = "";
        APP.isIpad = "";
        APP.isSafari = "";
        APP.isHome = "";
    </script>

    <script src="{{ asset('frontend') }}/js/vendor.js"></script>
    <script src="{{ asset('frontend') }}/js/site.js"></script>
    <script>
        $(function() {
            $('.nav-tabs').responsiveTabs();
        });
    </script>

</body>

</html>
