<!DOCTYPE html>
<html lang="en-US">

<head>
   @include('FrontEnd.includes.meta&links')
</head>

<body data-ng-app="siteApp" data-ng-cloak>
    @include('FrontEnd.includes.header')
    <div class="main-container">
        <section class="article-section animatedParent animateOnce" style="background-color: rgb(255, 255, 255)">
            <h1 class="animated fadeInDownShort">Our Blog</h1>
            <div class="articles">
                @foreach($blogs as $blog)
                <div class="article figure">
                   
                    <div class="article-image article1">
                        <a href=""
                            target="_blank">
                            <img data-lazy="{{ asset('backend/blog/' . $blog->image) }}" type="image"
                                alt="Bridal Harmony - Bridal Harmony’s New Streaming Service" src="#">
                        </a>
                    </div>
                    <div class="figcaption">
                        <a href=""
                            target="_blank">
                            {{$blog->title}}</a>
                    </div>
                    <div class="description">
                        <p>{{ Str::words(strip_tags($blog->description), 50) }}</p>
                    </div>
                    <p class="read-more"><a
                            href=""
                            target="_blank">Read More</a></p>
                    <p class="publisher">- Lifestyle Asia</p>
                    
                </div> 
                @endforeach 
                 
            </div>
        </section>
    </div>
    @include('FrontEnd.includes.footer')
   
    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');
    </script>
    <!--GA code end-->


    <!-- Scripts -->

    <script>
        var APP = APP || {};
        APP.baseUrl = "https://www.theweddingfilmer.com/";
        APP.env = "production";
        window.Laravel = {
            "csrfToken": "pBMmAMmcYJIimuwoVWUjOs4sdDTYCNeOBmeQkYmx"
        };
        APP.isMobile = "";
        APP.isIpad = "";
        APP.isSafari = "";
        APP.isHome = "";
    </script>

<script src="{{asset('frontend')}}/js/vendor.js"></script>
<script src="{{asset('frontend')}}/js/site.js"></script>

</body>

</html>
