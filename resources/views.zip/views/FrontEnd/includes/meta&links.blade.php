<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- CSRF Token -->
<meta name="csrf-token" content="oSDMHzS057TVIb80jp6lQnWDA8rckT1gonsthhxk" />

<!-- Meta tags -->
<meta name="title" content="Best Wedding Videography | Cinematic Wedding Videographers in Bangladesh – Bridal Harmony" />
<meta name="description" content="Bridal Harmony is not only the best wedding videographers in Bangladesh but also award-winning cinematic wedding filmmaker. We bring magic of movies to our wedding films. To view our wedding portfolio Visit Now!" />
<meta name="keywords" content="best wedding videographers, best wedding filmers in Bangladesh, best wedding videography in Bangladesh, cinematic wedding videography, wedding videography, wedding, filming, cinematic wedding" />
<meta name="author" content="Jamal Karim" />
<!-- Meta tags -->

<!-- FB meta tags -->
{{-- <meta property="og:url"                content="https://www.theweddingfilmer.com/" /> --}}
{{-- <meta property="og:type"               content="website" />
<meta property="og:title"              content="Bridal Harmony" />
<meta property="og:description"        content="The award-winning wedding filmmaker Jamal Karim and his crew of internationally acclaimed technicians brings the magic of movies to wedding films." />
<meta property="og:image"              content="https://www.theweddingfilmer.com/images/seo/5DOfYuU59UNBSuJp98srtkY1dgFzYtkQj5O009SZ.jpeg" /> --}}
<!-- FB meta tags -->

<!-- bing meta tag -->
<meta name="msvalidate.01" content="41FB85D518052C91344F2A957D2FE982" />
<!-- bing meta tag -->

<title>Best Wedding Videography | Cinematic Wedding Videographers in Bangladesh – Bridal Harmony</title>

<link rel="shortcut icon" href="{{ asset('backend/system_setting/logo.png') }}" type="image/x-icon" />
<link rel="icon" href="{{ asset('backend/system_setting/logo.png') }}" type="image/x-icon" />

<link rel="stylesheet" type="text/css" href="{{asset('frontend')}}/css/style.css" />
<link rel="stylesheet" type="text/css" href="{{asset('frontend')}}/css/app.css" />

<!-- Publisher link -->
<link rel="publisher" href="https://plus.google.com/109313288734466057512">

{{-- <link href="//capp.nicepage.com/d25269acc1f4c932c5867f91279aeb7f93916ac0/main-libs.css" rel="stylesheet" /> --}}
<!-- publisher link -->

<!--[if lte IE 9]>
<link href="https://www.theweddingfilmer.com/css/site/animations-ie-fix.css" rel='stylesheet'/>
<![endif]-->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5VZDVKK');</script>
<!-- End Google Tag Manager -->


<!-- onesignal -->
{{-- <link rel="manifest" href="https://www.theweddingfilmer.com/manifest.json" /> --}}
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
    var OneSignal = window.OneSignal || [];
    OneSignal.push(function() {
        OneSignal.init({
            appId: "1f7f5704-16db-4429-b7e4-6bcf69f436e3",
        });
    });
</script>

<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window,document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '167523987204667');
    fbq('track', 'PageView');
</script>
<!-- End Facebook Pixel Code -->


