
    <header class="master-header">
        <div>
            @php
                $logo = App\Models\BackEnd\SystemSetting::first();
            @endphp
            <a href=""><img src="{{ asset('backend/system_setting/' . $logo->logo) }}"
                    class="mobile twf-mobile-logo clear" alt="Bridal Harmony - Logo"></a>

        </div>
        <div class="mobile-tab hide">
            <div id="nav-icon4">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <nav class="navbar" id="nav">
            <ul class="desk-nav">
                <li>
                    <ul class="header-left">
                        {{-- <li><a href="" class="nav active">Home</a></li>
                        <li><a href="" class="nav ">About Us</a></li>
                        <li><a href="" class="nav ">Portfolio</a></li>
                        <li><a href="" class="nav ">Packages</a></li> --}}
                        <li><a href="{{route('home')}}" class="nav {{ request()->is('/') ? 'active' : ''}}" id="activenav">Home</a></li>
                        <li class=""><a href="" class="nav  ">About Us</a></li>
                        <li class=""><a href="{{route('our_work')}}" class="nav {{ request()->is('our_work') ? 'active' : ''}}">Portfolio</a></li>
                    </ul>
                </li>
                <li class="logo-image"><a href="" class="nav"><img class="twf-logo"
                            src="{{ asset('backend/system_setting/' . $logo->logo) }}" alt="Bridal Harmony - Logo"> </a>
                </li>
                <li>
                    <ul class="header-right">
                        {{-- <li><a href="" class="nav">Blog</a></li>
                        <li><a href="" class="nav">Contact Us</a></li>
                        <li><a href="{{route('admin.login')}}" class="nav nav-button ">Login</a></li> --}}
                        <li class="collapse"><a href="{{route('blogs')}}" class="nav {{ request()->is('blogs') ? 'active' : ''}}">Blog</a></li>
                        <li class="collapse"><a href="{{route('packages')}}" class="nav {{ request()->is('packages') ? 'active' : ''}} ">Packages</a></li>
                        <li class="collapse"> <a href="" class="nav">Contact Us</a></li>
                        <li class=""><a href="{{route('admin.login')}}" class="{{request()->is('/','blogs') ? 'nav nav-button ' : 'btn btn-md btn-primary'}}">Login</a></li>
    
                        {{-- <li><a href="https://www.theweddingfilmer.com/faqs" class="nav ">FAQ<small>s</small></a></li> --}}
                    </ul>
                </li>
            </ul>
        </nav>
    </header>
 
