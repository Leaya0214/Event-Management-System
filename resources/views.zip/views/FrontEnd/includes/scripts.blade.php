
    <!--GA code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-87651849-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-87651849-1');
        gtag('config', 'AW-774381738');

    </script>
    <!--GA code end-->


<!-- Scripts -->

<script>
    var APP = APP || {};
    APP.baseUrl = "https://www.theweddingfilmer.com/";
    APP.env = "production";
    window.Laravel = {"csrfToken":"oSDMHzS057TVIb80jp6lQnWDA8rckT1gonsthhxk"};
    APP.isMobile = "";
    APP.isIpad = "";
    APP.isSafari = "";
    APP.isHome = "1";
</script>

<script src="{{asset('frontend')}}/js/vendor.js"></script>
<script src="{{asset('frontend')}}/js/site.js"></script>
