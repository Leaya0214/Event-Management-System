@extends('welcome')
@section('header')
@include('FrontEnd.includes.header')
@endsection

@section('content')


<style>
    /* Default height for mobile */
    .responsive-image {
        height: 100px;
    }

    /* Media query for PC */
    @media screen and (min-width: 768px) {
        .responsive-image {
            height: 500px;
        }
    }
</style>


<style>
    /* Default styling for grid items */
    .fold2-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 10px;
        text-align: center;
    }

    .grid-item {
        background-color: #f0f0f0;
        padding: 10px;
        border-radius: 5px;
    }

    /* Media query for mobile devices */
    @media screen and (max-width: 767px) {
        .fold2-container {
            grid-template-columns: 1fr;
        }
    }

    /* Media query for larger screens (PC) */
    @media screen and (min-width: 768px) {
        .fold2-container {
            grid-template-columns: repeat(4, 1fr); /* Adjust the number of columns as needed */
        }
    }
</style>




 


<section class="video-container animatedParent">
    <div class="video">
        <video id="twf-bg-video" muted>
            <source src="{{ asset('backend/slider/' . $slider->video) }}" type="video/mp4" />
        </video>
    </div>

    <div class="mobile logo" id="logo">
        <div class="animated rotateIn delay-500">
            <img class="logo-img" src="{{ asset('backend/system_setting/' . $logo->logo) }}"
                alt=" Bridal Harmony - Logo Image">
        </div>
    </div>

    <div class="down-arrow ">
        <img id="down_arrow" src="{{ asset('frontend/images/arrow-down.png') }}" class="animated bounce"
            alt=" Bridal Harmony - down arrow">
    </div>
</section>
 <section class="fold2-container animatedParent animated" data-sequence="500">
    <div class="grid-item" id="eventsItem"><p>Events</p> <span>0</span></div>
    <div class="grid-item" id="packagesItem"><p>Packages</p> <span>0</span></div>
    <div class="grid-item" id="photosItem"><p>Photos</p> <span>0</span></div>
    <div class="grid-item" id="clientsItem"><p>Clients</p><span> 0</span></div>

    <script>
        function startCountdown() {
            // Set the fixed target values for the countdown
            const targetValues = {
                events: 600,
                packages: 300,
                photos: 800000,
                clients: 400
            };

            // Set the interval for updating the values (in milliseconds)
            const interval = 10; // 1 second

            const timers = Object.create(null);

            // Update the values at regular intervals
            function updateValues() {
                for (const itemId in targetValues) {
                    const item = document.getElementById(`${itemId}Item`);
                    const currentValue = parseInt(item.querySelector('span').textContent, 10);
                    const targetValue = targetValues[itemId];

                    if (currentValue < targetValue) {
                        // Increment the value by 1
                        item.querySelector('span').textContent = currentValue + 1;
                    } else {
                        // Stop the timer when the target value is reached
                        clearInterval(timers[itemId]);
                    }
                }
            }

            // Start the countdown when the page loads
            document.addEventListener('DOMContentLoaded', () => {
                for (const itemId in targetValues) {
                    timers[itemId] = setInterval(updateValues, interval);
                }
            });
        }
        
        startCountdown();
    </script>
    
    
</section>
<section class="service-section animatedParent animateOnce">
    <h1 class="animated fadeInDownShort">Our Services</h1>
    <div class="service-container">
        @foreach ($services as $service)
            <div class="service">
                <div class="container">
                    <div class="service-wrapper ">
                        <a href="#" data-url="{{ asset('backend/service/' . $service->image_video) }}">
                            <img class="responsive-image" src="{{ asset('backend/service/' . $service->image_video) }}"
                                alt="Bridal Harmony | Bridal Harmony" >
                        </a>
                    </div>
                    <div class="description">
                        <h2 class="animated fadeInUpShort">{{ $service->title }}</h2>
                        <div class="description-text animated fadeInUpShort">
                            <p>{!! $service->description !!}</p>
                            <p>Photo Credits: Bridal Harmony</p>

                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach

    </div>
</section>
{{-- <section class="fold2-container animatedParent animated" data-sequence="500">
    <h1 class="animated fadeInDownShort">Clients Review</h1>
    <div class="art-container">
        <img class="cover animated flipInY" data-id="1"
            src="https://www.theweddingfilmer.com/images/home/art_image.png"
            alt="Bridal Harmony - Sufi figure icon">
    </div>
    <div class="quote-section">
        <div class=" quote-left animated lightSpeedInLeft" data-id="1">
            <img class="quotes" src="https://www.theweddingfilmer.com/images/home/quote-left.png"
                alt="Bridal Harmony - Quotes">
        </div>
        <div class="quote-text">
            <div class="animated fadeIn" data-id="2">
                <p>Nothing is ever lost to us, as long as we remember it.</p>
            </div>
            <p class="quote-by animated fadeIn" data-id="2">- Vishal Punjabi</p>
        </div>
        <div class="quote-right  animated lightSpeedInRight" data-id="1">
            <img class="quotes" src="https://www.theweddingfilmer.com/images/home/quote-right.png"
                alt="Bridal Harmony - Quotes">
        </div>
    </div>
</section> --}}
<section class="article-section animatedParent animateOnce">
    <h1 class="animated fadeInDownShort">Our Blog</h1>
    <div class="articles">
        @foreach($blogs as $blog)
        <div class="article figure">
           
            <div class="article-image article1">
                <a href=""
                    target="_blank">
                    <img data-lazy="{{ asset('backend/blog/' . $blog->image) }}" type="image"
                        alt="Bridal Harmony - Bridal Harmony’s New Streaming Service" src="#">
                </a>
            </div>
            <div class="figcaption">
                <a href=""
                    target="_blank">
                    {{$blog->title}}</a>
            </div>
            <div class="description">
                <p>{{ Str::words(strip_tags($blog->description), 50) }}</p>
            </div>
            <p class="read-more"><a
                    href=""
                    target="_blank">Read More</a></p>
            <p class="publisher">- Lifestyle Asia</p>
            
        </div> 
        @endforeach 
         
    </div>
            
    <div class="press-page-link animated fadeInDownShort">
        <p><a href="/" class="press-page-button">Show All</a></p>
    </div>
</section>
<section class="story-section animatedParent animateOnce">
    <h1 class="animated fadeInDownShort">RECENT WORK</h1>

    <div class="videos-container">
        @foreach($portfolios as $portfolio)
        <div class="video">
            <div class="container">
                <div class="video-wrapper">
                    <a href=""
                        data-url="{{ getYoutubeEmbedUrl($portfolio->video) }}" tabindex="-1">
                        <img class="responsive-image"  src="{{ asset('backend/portfolio/' . $portfolio->image) }}"
                            alt="Bridal Harmony">
                        <div class="play-icon"><img
                                src="{{asset('frontend/images/play-icon.png')}}"
                                alt="Bridal Harmony - video play icon"></div>
                    </a>
                </div>
                <div class="description">
                    <h2 class="animated fadeInUpShort">Wedding</h2>
                    <div class="description-text animated fadeInUpShort">
                        <p>{{ Str::words(strip_tags($portfolio->description), 50) }}</p>
                        <p>Film Credits: Bridal Harmony</p>

                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>




<!--<section class="subscribe-section animatedParent animateOnce">-->
<!--    <div class="subscribe-wrapper">-->
<!--        <h3 class="animated fadeInDown" data-id="1">Clients Review </h3>-->
        
<!--        {{-- <form action="https://www.theweddingfilmer.com/blog/?na=s" onsubmit="return newsletter_check(this)"-->
<!--            method="post">-->
<!--            <input type="hidden" name="nr" value="widget">-->
<!--            <input class="animated fadeInLeft" type="email" required="" name="ne"-->
<!--                placeholder="Enter Email ID" onclick="if (this.defaultValue==this.value) this.value=''"-->
<!--                onblur="if (this.value=='') this.value=this.defaultValue">-->
<!--            <input class="animated fadeInRight primary-button hov-bk" type="submit" value="Subscribe Now">-->
<!--        </form> --}}-->
<!--    </div>-->
<!--</section>-->



@endsection