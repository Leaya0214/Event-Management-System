<!DOCTYPE html>
<html lang="en-US">

<head>
    @include('FrontEnd.includes.meta&links')
</head>

<body data-ng-app="siteApp" data-ng-cloak>

    <!-- Google Tag Manager (noscript) -->
    {{-- <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5VZDVKK"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> --}}
    <!-- End Google Tag Manager (noscript) -->

    @include('FrontEnd.includes.header')


    <div class="main-container">
        @yield('content')
    </div>

    @include('FrontEnd.includes.footer')

    @include('FrontEnd.includes.scripts')

</body>

</html>
